/*
 ============================================================================
 Name        : GapFiller.cpp
 Author      : Francesco Vezzi, Francesca Nadalin
 Version     : 1.1.1
 Copyright   : Your copyright notice
 Description : A de novo local assembler for paired reads
 ============================================================================
 */

using namespace std;

#include <stdlib.h>
#include <pthread.h>
#include <stdio.h>

#include <boost/thread/thread.hpp>
#include <boost/iostreams/filtering_stream.hpp>
#include <boost/iostreams/filter/gzip.hpp>
#include <boost/iostreams/filter/bzip2.hpp>
#include <boost/iostreams/device/file.hpp>
#include <boost/random.hpp>
#include <boost/lexical_cast.hpp>
using namespace boost;

#include <boost/program_options.hpp>
namespace po = boost::program_options;

#include "algorithms/Counting_Sort_By_Index.h"
#include "algorithms/Radix_Sort_By_Index.h"
using namespace algorithms;

#include "data_structures/Hash.h"
#include "data_structures/Mask.h"
//#include "io/formatting.h" //in the future implement trimming

#include "io/Fastq.h"
#include "io/Auto_Unzip.h"

#include "data_structures/Reads.h"

using namespace fastq;
using namespace useful;
using namespace reads;

Fastq::FASTQ_type fastqformat;
bool force_fastqformat = false;
string outputHeader;

// int threads_number = 1;

// sequence length to be mapped by hashing function
unsigned int blockLength = 15;

typedef boost::mt19937 RNGType;
RNGType rng;
boost::uniform_real<> double_range(0, 1); // [0..1)
boost::variate_generator<RNGType&, boost::uniform_real<> > guessRes(rng, double_range);

Mask::t_min_phred_value_CLC min_phred_value_CLC = 15;
Mask::t_min_phred_value_CLC min_mean_quality = 15;
t_pattern_length min_size = 15;

//bool onlyFilter = false;

void createHash(const vector<string> & fasta_files, const string & output_file);
unsigned int FileRead(istream & is, vector<char> & buff);
unsigned int CountLines(const vector<char> & buff, int sz);
void FilerLowQualityReadsForAssembly(const vector<string>, const vector<string>);

//unsigned short * convert(const char * seq, size_t n);
unsigned char * convert(const char * seq, size_t n);
unsigned char * convert(unsigned int *, unsigned short n);

void process_mem_usage(double& vm_usage, double& resident_set) {
	using std::ios_base;
	using std::ifstream;
	using std::string;

	vm_usage = 0.0;
	resident_set = 0.0;

	ifstream stat_stream("/proc/self/stat", ios_base::in);

	// dummy vars for leading entries in stat that we don't care about
	string pid, comm, state, ppid, pgrp, session, tty_nr;
	string tpgid, flags, minflt, cminflt, majflt, cmajflt;
	string utime, stime, cutime, cstime, priority, nice;
	string O, itrealvalue, starttime;

	// the two fields we want
	//short_ins + short_var
	unsigned long vsize;
	long rss;

	stat_stream >> pid >> comm >> state >> ppid >> pgrp >> session >> tty_nr
				>> tpgid >> flags >> minflt >> cminflt >> majflt >> cmajflt
				>> utime >> stime >> cutime >> cstime >> priority >> nice >> O
				>> itrealvalue >> starttime >> vsize >> rss; // don't care about the rest

	long page_size_kb = sysconf(_SC_PAGE_SIZE) / 1024; // in case x86-64 is configured to use 2MB pages
	vm_usage = vsize / 1024.0;
	resident_set = rss * page_size_kb;
}

void ComputeTempReads(Hash* HashHead, Contig* contig, unsigned int j,
		unsigned int Extposition, unsigned int pos,
		vector<unsigned int*> &reads_for_ext, unsigned int read_length,
		unsigned int globalMismatch, bool seed_16mer, bool no_cycle,
		bool verbose);
void ComputeExtReads(Hash* HashHead, Contig* contig, unsigned int* it,
		unsigned int read_length, unsigned int globalMismatch,
		const string & cons, unsigned int cons_start, Seeds* s_iter,
		vector<pair<unsigned int, bool> > & low_rep, bool verbose);
unsigned int SelectRepresentativeRead(Hash* HashHead, const string & cons,
		unsigned int cons_start, vector<unsigned int*> &reads_for_ext,
		unsigned int first_pos, vector<pair<unsigned int, bool> > & low_rep);
vector<unsigned int*> ComputeExtReadsBranch(Hash* HashHead, Contig* contig,
		vector<unsigned int*> &reads_for_ext, unsigned int read_length,
		unsigned int globalMismatch, int branch_mismatch,
		unsigned int first_pos, Seeds* s_iter, string cons,
		unsigned int cons_start, vector<pair<unsigned int, bool> > low_rep,
		bool verbose);
void verb_printConsensus(Contig* contig, unsigned int first_pos,
		unsigned int extThreshold, int slack, double perc_identity,
		bool branch);
void verb_printRead(const string & electedSequence, unsigned int start);

int main(int argc, char *argv[]) {

	// PROCESS PARAMETERS
	stringstream ss;
	ss << fast_description() << endl << endl << "Allowed options";
	po::options_description desc(ss.str().c_str());
	desc.add_options()
	("help", "produce help message")
	("k", po::value<int>(), "length of the word used to hash (default: 12)")
	("block-length", po::value<unsigned int>(), "length of perfect match (default: 15)")
	("output", po::value<string>(), "output file")
	("statistics", po::value<string>(), "statistics file")
	("layout", po::value<string>(), "layout file (optional; incompatible with --query)")
	("overlap", po::value<unsigned int>(), "minimum suffix-prefix overlap (default: 50)")
	("slack", po::value<int>(), "number of overlaps: suffix-prefix overlap range is [overlap, overlap + slack] (default: 40)")
	("seed1", po::value<vector<string> >(), "seed1 file (can be compressed with gzip or bzip2, or a pipe)")
	("seed2", po::value<vector<string> >(), "seed2 file (can be compressed with gzip or bzip2, or a pipe)")
	//("short-1", po::value< vector < string > >(), "query1 file (can be compressed with gzip or bzip2, or a pipe)")
	//("short-2", po::value< vector < string > >(), "query2 file (can be compressed with gzip or bzip2, or a pipe)")
	("query", po::value<vector<string> >(), "query file: use different reads for extension instead of seeds (can be compressed with gzip or bzip2, or a pipe)")
	("seed-ins", po::value<unsigned int>(), "seed reads insert size")
	("seed-var", po::value<unsigned int>(), "seed reads insert variation")
	/*
	 ("quality-cutoff", po::value<Mask::t_min_phred_value_CLC>(), "quality cutoff in read filtering" )
	 ("threads", po::value<unsigned int>(), "maximum number of allowed threads (default 1)")
	 ("seed-16-mer", "use 16-mer coverage information to select seed reads")
	 ("min-coverage", po::value<unsigned int>(), "min coverage cut-off")
	 // (reads below this threshold are likely to contain errors)
	 ("max-coverage", po::value<unsigned int>(), "max coverage cut-off")
	 // (reads over this threshold are likely to belong to repetitions)
	 */
	("read-length", po::value<unsigned int>(), "maximum read length (default: 100)")
	("global-mismatch", po::value<int>(), "maximum number of mismatches between mate and contig (default: 5)")
	("extThr", po::value<unsigned int>(), "extThreshold: number of reads needed to extend a contig (default: 2)")
	("perc-identity", po::value<double>(), "min percentage of identity for a high-rep position (default: 0.6)")
	("limit", po::value<unsigned int>(), "limits the number of extended reads (useful for tests)")
	("no-read-cycle", "suppress read-cycle stop condition (default: false)")
	("mate-count-only", "count how many time the mate is found instead of stopping the extension (default: false)")
	("min-length", po::value<unsigned int>(), "print only contigs >= min-length long (default: 0)")
	("max-length", po::value<unsigned int>(), "print only contigs <= max-length long (default: 800; set to seed-ins + seed-var if provided)")
	("mate-pairs", "default: paired-ends")
	("branch", "perform multiple extensions (default: false)")
	("max-branches", po::value<unsigned int>(), "maximum number of branches for each seed (default: 3)")
	("mismatch-branch", po::value<int>(), "minimum number of mismatches needed to open a new branch (default: 3*global_mismatch)")
	("verbose", "print a lot of information! Use with --limit option");

	po::variables_map vm;
	try {
		po::store(po::parse_command_line(argc, argv, desc), vm);
		po::notify(vm);
	} catch (boost::program_options::error error) {
		cerr << error.what() << endl;
		cerr << "Try \"--help\" for help" << endl;
		exit(2);
	}

	if (vm.count("help")) {
		cout << desc << endl;
		exit(0);
	}

	//////////////////////
	// INPUT PARAMETERS //
	//////////////////////

	// hash word length

	int k = 12;
	if (vm.count("k")) {
		k = vm["k"].as<int> ();
		if (k > 15 or k < 1) {
			cerr << "--k parameter must be a positive number less or equal to 15" << endl;
			exit(1);
		}
	}

	if (vm.count("block-length")) {
		blockLength = vm["block-length"].as<unsigned int> ();
	}

	// output files

	if (not (vm.count("output"))) {
		cerr << "output option required" << endl;
		cerr << "Try \"--help\" for help" << endl;
		exit(1);
	} else {
		outputHeader = vm["output"].as<string> ();
	}

	string statisticsFile;
	if (not (vm.count("statistics"))) {
		cerr << "statistics option required" << endl;
		cerr << "Try \"--help\" for help" << endl;
		exit(1);
	} else {
		statisticsFile = vm["statistics"].as<string> ();
	}

	string layoutFileName;
	bool layout = false;
	if (vm.count("layout")) {
		if (vm.count("query")){
			cerr << "Cannot use both --query and --layout" << endl;
			exit(1);
		} else {
			layout = true;
			layoutFileName = vm["layout"].as<string> ();
		}
	}

	// overlap parameters

	unsigned int overlap = 50;
	if (vm.count("overlap")) {
		overlap = vm["overlap"].as<unsigned int> ();
		if (overlap < blockLength) {
			cerr << "--overlap parameter must be less or equal to "
				 << blockLength << endl;
			exit(1);
		}
		min_size = overlap;
	}

	unsigned int slack = 40;
	if (vm.count("slack")) {
		slack = vm["slack"].as<int> ();
	}

	// seed files and seed insert

	vector<string> seed_fw_files;
	vector<string> seed_rv_files;

	unsigned int seed_ins;
	unsigned int seed_var;

	unsigned int max_contig_length = 800;
	unsigned int min_contig_length = 0;

	if (not (vm.count("seed1") and vm.count("seed2"))) {
		cerr << "--seed1 and --seed2 options must be provided" << endl;
		exit(1);
	} else {
		seed_fw_files = vm["seed1"].as<vector<string> > ();
		seed_rv_files = vm["seed2"].as<vector<string> > ();
		if (not vm.count("seed-ins") or not vm.count("seed-var")) {
			cout << "--seed-ins and --seed-var must be provided" << endl;
			exit(1);
		} else {
			seed_ins = vm["seed-ins"].as<unsigned int> ();
			seed_var = vm["seed-var"].as<unsigned int> ();
			max_contig_length = seed_ins + seed_var;
		}
	}

	if (seed_fw_files.size() != seed_rv_files.size()) {
		cerr << "Different number of first and second seed reads files" << endl;
		exit(1);
	}

	vector<string> query_files;

	bool seeds_as_query = true;
	if (not vm.count("query")) {
		cout << "use seed reads for extension" << endl;
	} else {
		seeds_as_query = false;
		query_files = vm["query"].as<vector<string> > ();
	}

	// parameters for seeds

	bool seed_16mer = false;
	unsigned int minCoverage = 1;
	unsigned int maxCoverage = 1000000;

	/*
	 if (vm.count("seed-16-mer")){
	 seed_16mer = true;
	 }

	 if (vm.count("min-coverage")) {
	 minCoverage = 1 + vm["min-coverage"].as<unsigned int>();
	 }

	 if (vm.count("max-coverage")) {
	 maxCoverage = 1 + vm["max-coverage"].as<unsigned int>();
	 }

	 if (vm.count("quality-cutoff")) {
	 min_phred_value_CLC = vm["quality-cutoff"].as<Mask::t_min_phred_value_CLC>();
	 min_mean_quality = vm["quality-cutoff"].as<Mask::t_min_phred_value_CLC>();
	 }
	 */

	// parameters for extension

	unsigned int read_length = 100;
	if (vm.count("read-length")) {
		read_length = vm["read-length"].as<unsigned int> ();
	}

	unsigned int globalMismatch = 5;
	if (vm.count("global-mismatch")) {
		globalMismatch = vm["global-mismatch"].as<int> ();
	}

	unsigned int extThreshold = 2;
	if (vm.count("extThr")) {
		extThreshold = vm["extThr"].as<unsigned int> ();
	}

	double perc_identity = 0.6;
	if (vm.count("perc-identity")) {
		perc_identity = vm["perc-identity"].as<double> ();
	}

	// global parameters

	bool limitedExtension = false;
	unsigned long int maxReadsToExtend = 10000;
	if (vm.count("limit")) {
		maxReadsToExtend = vm["limit"].as<unsigned int> ();
		limitedExtension = true;
	}

	bool no_cycle = false;
	if (vm.count("no-read-cycle")) {
		no_cycle = true;
	}

	bool mate_count_only = false;
	if (vm.count("mate-count-only")) {
		mate_count_only = true;
	}

	bool reverse_seed = false;
	bool reverse_mate = true;
	if (vm.count("mate-pairs")) {
		reverse_seed = true;
		reverse_mate = false;
	}

	if (vm.count("min-length")) {
		min_contig_length = vm["min-length"].as<unsigned int> ();
	}
	if (vm.count("max-length")) {
		max_contig_length = vm["max-length"].as<unsigned int> ();
	}

	bool branch = false;
	if (vm.count("branch")) {
		branch = true;
		extThreshold = 1;
	}

	unsigned int max_branches = 3;
	if (vm.count("max-branches")) {
		max_branches = vm["max-branches"].as<unsigned int> ();
	}

	int branch_mismatch = 3 * globalMismatch;
	if (vm.count("mismatch-branch")) {
		branch_mismatch = vm["mismatch-branch"].as<int> ();
	}

	bool verbose = false;
	if (vm.count("verbose")) {
		verbose = true;
	}

	///////////////////////////////
	// STORE READS FOR EXTENSION //
	///////////////////////////////

	rng.seed(time(0)); // random number
	cout << "Compute number of Reads" << endl;

	size_t totalReadNum = 0;

	double vm_usage, rss_usage;
	process_mem_usage(vm_usage, rss_usage);
	cout << "initialization: VM: " << vm_usage << "; RSS: " << rss_usage << endl;

	clock_t start;
	clock_t time1;
	clock_t time2;
	start = time1 = clock();

	vector<Reads> readsMultiTMP;
	unsigned int max_read_length = 0;

	if (seeds_as_query) {

		vector<string>::const_iterator iter_fw;
		vector<string>::const_iterator iter_rv;

		for (iter_fw = seed_fw_files.begin(), iter_rv = seed_rv_files.begin();
			 iter_fw != seed_fw_files.end();
			 iter_fw++ , iter_rv++) {

			Auto_Unzip input_file_fw(*iter_fw);
			Auto_Unzip input_file_rv(*iter_rv);
			istream & inputFileFW = input_file_fw.filtered();
			istream & inputFileRV = input_file_rv.filtered();

			Fastq read_fw;
			Fastq read_rv;

			Fastq::FASTQ_type type_fw = Fastq::check_FASTQ_type_file(iter_fw->c_str());

			read_fw.set_input_type(type_fw);
			read_rv.set_input_type(type_fw);

			while (not inputFileFW.eof() and not inputFileRV.eof()) {
				inputFileFW >> read_fw;
				inputFileRV >> read_rv;

				Reads tmp = Reads(read_fw.get_sequence(), true);
				tmp.setCoverage(read_fw.coverage());
				if (read_fw.get_sequence().size() > max_read_length) {
					max_read_length = read_fw.get_sequence().size();
				}

				if(read_fw.coverage() >= minCoverage and read_fw.coverage() <= maxCoverage) {
					tmp.setSeed();
				}
				readsMultiTMP.push_back(tmp);

				tmp = Reads(read_rv.get_sequence(), false);
				if (read_rv.get_sequence().size() > max_read_length) {
                                        max_read_length = read_rv.get_sequence().size();
                                }

				tmp.setCoverage(read_rv.coverage());
				if(read_rv.coverage() >= minCoverage and read_rv.coverage() <= maxCoverage) {
					tmp.setSeed();
				}
				readsMultiTMP.push_back(tmp);

				totalReadNum +=2;

				if(totalReadNum % 100000 == 0) {
					cout << ".";
					if(totalReadNum % 10000000 == 0) {
						cout << endl;
					}
				}
			}
		}

	} else {

		vector<string>::const_iterator iter_query;

		for (iter_query = query_files.begin(); iter_query != query_files.end(); iter_query++) {
			Auto_Unzip input_file_query(*iter_query);
			istream & inputFilequery = input_file_query.filtered();

			Fastq read_query;
			Fastq::FASTQ_type type_query = Fastq::check_FASTQ_type_file(iter_query->c_str());
			read_query.set_input_type(type_query);

			while (not inputFilequery.eof()) {
				inputFilequery >> read_query;

				Reads tmp = Reads(read_query.get_sequence(), true);
				if (read_query.get_sequence().size() > max_read_length) {
                                        max_read_length = read_query.get_sequence().size();
                                }

				tmp.setCoverage(read_query.coverage());
				if (read_query.coverage() >= minCoverage and read_query.coverage() <= maxCoverage) {
					tmp.setSeed();
				}
				readsMultiTMP.push_back(tmp);
				totalReadNum++;

				if(totalReadNum % 100000 == 0) {
					cout << ".";
					if(totalReadNum % 10000000 == 0) {
						cout << endl;
					}
				}
			}
		}
	}

	cout << endl;
	cout << "total number of reads for extension is " << totalReadNum << endl;

	time2 = clock();
	cout << "time needed for read sequences: " << (double) (time2 - time1) / CLOCKS_PER_SEC << " s" << endl;
	time1 = time2;

	process_mem_usage(vm_usage, rss_usage);
	cout << "reads memorized in readsMultiTmp VM: " << vm_usage << "; RSS: " << rss_usage << endl;

	Hash *HashHead = new Hash(k, blockLength, 1, readsMultiTMP.size());

	process_mem_usage(vm_usage, rss_usage);
	cout << "Hash created VM: " << vm_usage << "; RSS: " << rss_usage << endl;

	size_t tmp_i = 0;
	for (vector<Reads>::iterator iter = readsMultiTMP.begin(); iter
			!= readsMultiTMP.end(); iter++) {
		HashHead->readsMulti[tmp_i++] = *iter;
	}

	process_mem_usage(vm_usage, rss_usage);
	cout << "HASH->readsMulti populated VM: " << vm_usage << "; RSS: " << rss_usage << endl;

	readsMultiTMP.clear();
	process_mem_usage(vm_usage, rss_usage);
	cout << "readMultiTMP deleted VM: " << vm_usage << "; RSS: " << rss_usage << endl;

	//HashHead->init();
	HashHead->init_by_strand(overlap);
	process_mem_usage(vm_usage, rss_usage);

	cout << "HASH populated: VM: " << vm_usage << "; RSS: " << rss_usage << endl;
	time2 = clock();
	cout << "time needed to populate HASH: " << (double) (time2 - time1) / CLOCKS_PER_SEC << " s" << endl;
	time1 = time2;

	if (limitedExtension) {
		cout << "Extend only " << maxReadsToExtend << "reads" << endl;
	}

	// open output files
	ofstream OutputFile;
	OutputFile.open(outputHeader.c_str());

	ofstream statisticsFiles;
	statisticsFiles.open(statisticsFile.c_str());

	ofstream layoutFile;
	if (layout) {
		layoutFile.open(layoutFileName.c_str());
		// print: read_id (in Reads), read position (within contig), read length, read strand (within contig)
		layoutFile << "# Store information on reads used within extensions, for each MATE_FOUND contig" << endl;
		layoutFile << "# Each line contains:" << endl;
		layoutFile << "# - contig_id" << endl;
		layoutFile << "# - read_id (position in Reads array), read coord (within contig), read length, read strand (within contig)" << endl;
	}

	///////////////////
	// ASSEMBLY TIME //
	///////////////////

	unsigned long int numberOfExtensions = 0;
	unsigned long int numberOfExtendedReads = 0;
	unsigned long int length = 0;

	unsigned long int stopNotPossibleExtensions = 0;
	unsigned long int stopRepetitiveSequence = 0;
	unsigned long int stopMatePairFound = 0;
	unsigned long int stopLengthMaximumExceed = 0;
	unsigned long int stopReadCycleFound = 0;

	statisticsFiles << "read_extended mean_extension_length StopbyNoMoreExt StopByRepSeq StopByLengthExceed StopByPairFound StopbyReadCycle" << endl;

	vector<string>::const_iterator iter_seed_fw;
	vector<string>::const_iterator iter_seed_rv;

	unsigned long int i = 0;
	unsigned int max_ext_length = 2 * max_read_length;

	// iterate on the couples of seed files

	for (iter_seed_fw = seed_fw_files.begin(), iter_seed_rv = seed_rv_files.begin();
		 iter_seed_fw != seed_fw_files.end(), iter_seed_rv != seed_rv_files.end();
		 iter_seed_fw++, iter_seed_rv++) {

		Auto_Unzip seed_file_fw(*iter_seed_fw);
		Auto_Unzip seed_file_rv(*iter_seed_rv);
		istream & seedFileFW = seed_file_fw.filtered();
		istream & seedFileRV = seed_file_rv.filtered();

		Fastq seed_fw;
		Fastq seed_rv;

		Fastq::FASTQ_type type_fw = Fastq::check_FASTQ_type_file(iter_seed_fw->c_str());

		seed_fw.set_input_type(type_fw);
		seed_rv.set_input_type(type_fw);

		string seed_string;
		string seed_mate_string;

		// compute one couple of seed files

		while (not seedFileFW.eof() and not seedFileRV.eof() and (not limitedExtension or i < maxReadsToExtend)) {

			if (verbose) {
				cout << endl;
				cout << "**** NEW SEED (" << i + 1 << ") ****" << endl;
				cout << endl;
			}

			i++;
			// seed ID is 2*(i-1)
			// seed mate ID is 2*i-1

			seedFileFW >> seed_fw;
			if (not reverse_seed) {
				seed_string = seed_fw.get_sequence();
				if (verbose) {
					cout << "seed_string: " << seed_string << endl;
				}
			} else {
				seed_string = seed_fw.reverse_complement();
				if (verbose) {
					cout << "seed_string: " << seed_string << endl;
				}
			}
			seedFileRV >> seed_rv;
			if (reverse_mate) {
				seed_mate_string = seed_rv.reverse_complement();
				if (verbose) {
					cout << "seed_mate_string: " << seed_mate_string << endl;
				}
			} else {
				seed_mate_string = seed_rv.get_sequence();
				if (verbose) {
					cout << "seed_mate_string: " << seed_mate_string << endl;
				}
			}

			/******************/

			// maybe multiple extensions from the same paired read
			vector<Seeds*> seeds_list;
			Seeds* element;
			element = new Seeds(seed_string, seed_mate_string);
			seeds_list.push_back(element);

			set<unsigned int> reads_used;
			unsigned int s_iter = 0;

			/******************/

			// extract position of seed in HASHvalues
			unsigned int seed_hashvalue;
			Contig seed_contig (seed_string, reads_used, i,
					seeds_list.at(s_iter)->seed_length(), HashHead->q, HashHead->h,
					HashHead->blockLength, overlap, slack);
			unsigned long fing = seed_contig.ComputeFingerprintForCheck(0);
			unsigned int p = HashHead->HASHcounter[fing];
			unsigned int l;
			if (fing == HashHead->returnQ() - 1) {
				l = 2 * HashHead->numReads;
			} else {
				l = HashHead->HASHcounter[fing + 1];
			}
			unsigned int j = p;
			bool found = false;
			while (j < l and not found) {
				found = (HashHead->HASHvalues[j].first == 2*(i-1));
				if (found) {
					seed_hashvalue = j;
				}
				j++;
			}

			// add the seed to the list of reads used for extension
			pair <unsigned int, unsigned int> p_ext;
			if (seeds_as_query) {
				p_ext.first = seed_hashvalue;
				p_ext.second = 0;
				seeds_list.at(s_iter)->extension_reads().push_back (p_ext);
			}

			// extract position of seed_mate in HASHvalues
			unsigned int seed_mate_hashvalue;
			Contig seed_mate_contig (seed_mate_string, reads_used, i,
							max_ext_length, HashHead->q, HashHead->h, HashHead->blockLength, overlap, slack);
			fing = seed_mate_contig.ComputeFingerprintForCheck(overlap - HashHead->blockLength);
			p = HashHead->HASHcounter[fing];
			if (fing == HashHead->returnQ() - 1) {
				l = 2 * HashHead->numReads;
			} else {
				l = HashHead->HASHcounter[fing + 1];
			}
			j = p;
			found = false;
			while (j < l and not found) {
				found = (HashHead->HASHvalues[j].first == 2*i-1);
				if (found) {
					seed_mate_hashvalue = j;
				}
				j++;
			}

			/*************/

			while (s_iter < seeds_list.size()) {

				if (seeds_list.at(s_iter)->seed_length() >= overlap) {

					if (verbose) {
						cout << endl;
						cout << "****NEW CONTIG****" << endl;
					}

					Contig *contig = new Contig(seeds_list.at(s_iter)->seed_string(), reads_used, i,
												max_ext_length, HashHead->q, HashHead->h,
												HashHead->blockLength, overlap, slack);
					numberOfExtendedReads++; // increment number of reads that have been extended

					unsigned int prev_position = 0; // first position to be searched for the mate
					if (seed_var < seed_ins and seed_ins - seed_var > seeds_list.at(s_iter)->seed_mate_length()) {
						prev_position = seed_ins - seed_var - seeds_list.at(s_iter)->seed_mate_length();
					}
					bool mateFound = false;

					while (contig->returnStatus() == Contig::Continue) {

						// MATE CHECK: only in the positions where it is supposed to occur (insert size)

						bool mate_stored = false;
						unsigned int mate_pos = prev_position;

						if (not mateFound and contig->ReturnContigLength() >= seeds_list.at(s_iter)->seed_mate_length()
							and contig->ReturnContigLength() + seed_var >= seed_ins
							and contig->ReturnContigLength() <= seed_ins + seed_var) {

							/********* Search for the mate among the reads used for extension ********/

							if (seeds_as_query){
								if (seeds_list.at(s_iter)->extension_reads().size() > 0) {
									int ii = seeds_list.at(s_iter)->extension_reads().size()-1;
									while (not mate_stored and ii >= 0 and seeds_list.at(s_iter)->extension_reads().at(ii).second >= prev_position) {
										mate_stored = (seeds_list.at(s_iter)->extension_reads().at(ii).first == seed_mate_hashvalue);
										mate_pos = seeds_list.at(s_iter)->extension_reads().at(ii).second;
										ii--;
									}
								}
								mateFound = mate_stored;
							}

							/********* Search for the mate pos-by-pos *********/

							if (not mate_stored) {
								while (not mateFound and mate_pos <= contig->ReturnContigLength() - seeds_list.at(s_iter)->seed_mate_length()) {

									if (contig->MaybeMateFound(seed_mate_string, mate_pos, globalMismatch)) {
										if (s_iter > 0 and seeds_list.at(s_iter)->seed_length() >= contig->ReturnContigLength()) {
											// mate has been found before
											contig->setStatus(Contig::NoMoreExtensions);
										} else {
											mateFound = true;
										}
									}
									mate_pos++;
								}
								prev_position = mate_pos;
								mate_pos -= mateFound;
							}
						}

						if (mateFound) {
							if (mate_count_only) {
								contig->setStatus(Contig::Continue);
								stopMatePairFound++;
							} else {
								if (verbose) {
									cout << "MATE FOUND!!!!" << endl;
								}
								contig->setStatus(Contig::MatePairFound);
							}
						}

						/******** Cut the current contig sequence after the mate *******/

						if (mateFound) {
							contig->resize(mate_pos + seeds_list.at(s_iter)->seed_mate_length());
						}

						/******** Drop the reads ending after the mate *******/

						int insert_position = seeds_list.at(s_iter)->extension_reads().size();
						if (mateFound) {
							if (seeds_list.at(s_iter)->extension_reads().size() > 0) {
								int ii = seeds_list.at(s_iter)->extension_reads().size() - 1;
								while (ii >= 0) {
									unsigned int r_start = seeds_list.at(s_iter)->extension_reads().at(ii).second;
									size_t r_size = HashHead->readsMulti[HashHead->HASHvalues[seeds_list.at(s_iter)->extension_reads().at(ii).first].first].length();
									if (r_start + r_size > mate_pos + seeds_list.at(s_iter)->seed_mate_length()) {
										// erase read
										if (verbose){
											cout << "Erase read " << HashHead->readsMulti[HashHead->HASHvalues[seeds_list.at(s_iter)->extension_reads().at(ii).first].first].toString(HashHead->HASHvalues[seeds_list.at(s_iter)->extension_reads().at(ii).first].second) << endl;
										}
										seeds_list.at(s_iter)->extension_reads().erase(seeds_list.at(s_iter)->extension_reads().begin() + ii);
									} else {
										// find the position in which the seed mate should be inserted
										if (seeds_as_query and not mate_stored and r_start >= mate_pos and
											not HashHead->HASHvalues[seeds_list.at(s_iter)->extension_reads().at(ii).first].second and
											(r_start > mate_pos or seeds_list.at(s_iter)->extension_reads().at(ii).first > seed_mate_hashvalue) ) {
											insert_position = ii+1;
										}
									}
									ii--;
								}
							}
						}

						/********* Add the seed mate to the list of reads used for extension ********/

						if (mateFound and seeds_as_query and not mate_stored) {
							p_ext.first = seed_mate_hashvalue;
							p_ext.second = mate_pos;
							if (insert_position < seeds_list.at(s_iter)->extension_reads().size()) {
								seeds_list.at(s_iter)->extension_reads().insert (seeds_list.at(s_iter)->extension_reads().begin() + insert_position, p_ext);
							} else {
								seeds_list.at(s_iter)->extension_reads().push_back (p_ext);
							}
						}

						if (verbose) {
							cout << "current contig: " << endl;
							cout << contig->returntContig() << endl;
							cout << "contig length: " << contig->ReturnContigLength() << endl;
						}

						// END MATE CHECK

						// EXTENSION TIME

						if (contig->returnStatus() == Contig::Continue) {

							numberOfExtensions++; // increment extensions number
							contig->InitializeExtension(); // initialize the extension phase

							//TODO : compute here the first fingerprint and compute the other
							// using she shift operation

							unsigned int Extposition = 0; // position of an overlapping read in the current extension
							bool no_more_ext = false;
							unsigned int first_pos; // initial position of the consensus

							if (seeds_list.at(s_iter)->leftmost() + overlap + slack < contig->ReturnContigLength()) {
								first_pos = contig->ReturnContigLength() - overlap - slack;
							} else {
								first_pos = seeds_list.at(s_iter)->leftmost();
							}

							// store the overlapping reads
							vector<unsigned int*> reads_for_ext;

							if (verbose) {
								cout << "TEMPORARY READS" << endl;
							}

							for (unsigned int pos = first_pos; pos <= contig->ReturnContigLength() - overlap; pos++, Extposition++) {

								// READS FORWARD
								fing = contig->ComputeFingerprintForCheck(pos);
								p = HashHead->HASHcounter[fing];
								if (fing == HashHead->returnQ() - 1) {
									l = 2 * HashHead->numReads;
								} else {
									l = HashHead->HASHcounter[fing + 1];
								}
								for (unsigned int j = p; j < l; j++) {
									// do not search for the seed again
									if (HashHead->HASHvalues[j].second and
										not (seeds_as_query and j == seed_hashvalue)) {
										ComputeTempReads(HashHead, contig, j, Extposition, pos, reads_for_ext, read_length, globalMismatch, seed_16mer, no_cycle, verbose);
									}
								}

								// READS REVERSE
								fing = contig->ComputeFingerprintForCheck(pos + overlap - HashHead->blockLength);
								p = HashHead->HASHcounter[fing];
								if (fing == HashHead->returnQ() - 1) {
									l = 2 * HashHead->numReads;
								} else {
									l = HashHead->HASHcounter[fing + 1];
								}
								for (unsigned int j = p; j < l; j++) {
									if (not HashHead->HASHvalues[j].second) {
										ComputeTempReads(HashHead, contig, j, Extposition, pos, reads_for_ext, read_length, globalMismatch, seed_16mer, no_cycle, verbose);
									}
								}

							}

							/**************************************/

							unsigned int errors;
							// low percentage + at least two char different from consensus
							vector<pair<unsigned int, bool> > low_rep; // <position, represented>
							// represented = true : low rep
							// represented = false : non rep
							unsigned int cons_start;
							unsigned int numfing;
							if (overlap + slack > contig->ReturnContigLength()) {
								numfing = contig->ReturnContigLength();
							} else {
								numfing = overlap + slack;
							}

							if (not branch) {
								// SINGLE EXTENSION
								string cons = contig->contigExtension->returnConsensus(extThreshold, numfing, errors, perc_identity, low_rep, cons_start);
								no_more_ext = (first_pos + cons_start + cons.length() <= contig->ReturnContigLength());
								if (verbose) {
									verb_printConsensus(contig, first_pos, extThreshold, slack, perc_identity, branch);
									cout << "EXTRACTED READS" << endl;
								}

								if (not no_more_ext) {
									contig->DeleteExtension();
									contig->InitializeExtension(); // initialize the extension phase
									Extposition = 0;
									for (vector<unsigned int*>::iterator it = reads_for_ext.begin(); it != reads_for_ext.end(); it++) {
										ComputeExtReads(HashHead, contig, *it, read_length, globalMismatch, cons, cons_start, seeds_list.at(s_iter), low_rep, verbose);
									}
								}
							} else {
								// MULTIPLE EXTENSION
								string cons = contig->contigExtension->returnConsensusBranch(errors, low_rep,cons_start);
								no_more_ext = (first_pos + cons_start + cons.length() <= contig->ReturnContigLength());
								if (verbose) {
									verb_printConsensus(contig, first_pos, extThreshold, slack, perc_identity, branch);
									cout << "EXTRACTED READS" << endl;
								}
								if (not no_more_ext) {
									// initialize branch seed
									Seeds seed_temp(seeds_list.at(s_iter)->seed_string(), seeds_list.at(s_iter)->seed_mate_string(), seeds_list.at(s_iter)->extension_reads());
									seed_temp.set_leftmost(seeds_list.at(s_iter)->leftmost());
									// here compute the current contig extension
									contig->DeleteExtension();
									contig->InitializeExtension(); // initialize the extension phase
									Extposition = 0;
									if (verbose) {
										cout << "first branch = current contig" << endl;
									}
									reads_for_ext = ComputeExtReadsBranch(HashHead, contig, reads_for_ext, read_length, globalMismatch, branch_mismatch, first_pos, seeds_list.at(s_iter), cons, cons_start, low_rep, verbose);
									// reads still alive here are those overlapping first read with too many mismatches

									while (seeds_list.size() < max_branches and reads_for_ext.size() > 0) {
										// do not re-use reads
										reads_used = contig->reads_used();
										// here compute the other branches
										Contig *contig_temp = new Contig(contig->returntContig(), i, max_ext_length, HashHead->q, HashHead->h, HashHead->blockLength, overlap, slack);
										contig_temp->InitializeExtension();
										if (verbose) {
											cout << "new branch" << endl;
										}
										reads_for_ext = ComputeExtReadsBranch(HashHead, contig_temp, reads_for_ext, read_length, globalMismatch, branch_mismatch, first_pos, &seed_temp, cons, cons_start, low_rep, verbose);
										// do not check the same reads, even though they actually belong to another branch
										if (seeds_list.at(s_iter)->leftmost() < seed_temp.leftmost()) {
											seeds_list.at(s_iter)->set_leftmost(seed_temp.leftmost());
										}
										// add contig_temp to the seed list
										contig_temp->extension(extThreshold, max_contig_length, perc_identity, no_more_ext, first_pos, branch);
										Seeds* temp_element;
										temp_element = new Seeds(contig_temp->returntContig(), seeds_list.at(s_iter)->seed_mate_string(), seed_temp.extension_reads());
										temp_element->set_leftmost(seeds_list.at(s_iter)->leftmost());
										seeds_list.push_back(temp_element);
										if (verbose) {
											cout << "seed contig: " << endl;
											cout << contig_temp->returntContig() << endl;
										}
										contig_temp->DeleteExtension();
										delete contig_temp;
									}
								}

							}

							/****************************************/

							contig->extension(extThreshold, max_contig_length, perc_identity, no_more_ext, first_pos, branch);
							if (verbose) {
								verb_printConsensus(contig, first_pos, extThreshold, slack, perc_identity, branch);
							}

							for (vector<unsigned int*>::iterator it = reads_for_ext.begin(); it != reads_for_ext.end(); it++) {
								delete[] (*it);
							}

							contig->DeleteExtension();
						}

						switch (contig->returnStatus()) {
						case Contig::LentghExceed:
							stopLengthMaximumExceed++;
							break;
						case Contig::NoMoreExtensions:
							stopNotPossibleExtensions++;
							break;
						case Contig::RepetitiveSequence:
							stopRepetitiveSequence++;
							break;
						case Contig::MatePairFound:
							stopMatePairFound++;
							break;
						case Contig::ReadCycleFound:
							stopReadCycleFound++;
							break;
						default:
							contig->setStatus(Contig::Continue);
							break; // MatePairFound or Continue
						}
					}

					// LAYOUT OUTPUT
					if (layout and contig->returnStatus() == Contig::MatePairFound) {
						// print information on reads used for all extensions
						layoutFile << "contig" << i;
						if (branch) {
							layoutFile << "_" << s_iter + 1;
						}
						layoutFile << "_pairFound";
						for (vector<pair<unsigned int, unsigned int> >::iterator iter = seeds_list.at(s_iter)->extension_reads().begin();
																				 iter != seeds_list.at(s_iter)->extension_reads().end();
																				 iter++) {
							// print: read_id (in Reads), read position (within contig), read length, read strand (within contig)
							layoutFile << " "
									<< HashHead->HASHvalues[(*iter).first].first
									<< "," << (*iter).second << ","
									<< HashHead->readsMulti[HashHead->HASHvalues[(*iter).first].first].length()
									<< ","
									<< HashHead->HASHvalues[(*iter).first].second;
						}
						layoutFile << endl;
					}

					// FASTA OUTPUT
					if (contig->ReturnContigLength() >= min_contig_length) {
						if (mate_count_only) {
							contig->printContigMate(OutputFile, mateFound);
						} else if (not branch) {
							contig->printContig(OutputFile);
						} else {
							contig->printContig(OutputFile, s_iter);
						}
						length += (unsigned long int) contig->ReturnContigLength();
					}

					// STATISTICS OUTPUT
					if ((numberOfExtendedReads % 10000) == 0) {
						double PartialMean = (double) numberOfExtensions / numberOfExtendedReads;
						cout << ".";
						statisticsFiles << numberOfExtendedReads << " "
								<< PartialMean << " "
								<< stopNotPossibleExtensions << " "
								<< stopRepetitiveSequence << " "
								<< stopLengthMaximumExceed << " "
								<< stopMatePairFound << " "
								<< stopReadCycleFound << endl;
					}

					delete contig;
				}

				delete seeds_list.at(s_iter);
				s_iter++;

			}
		}
	}

	double mean = (double) numberOfExtensions / numberOfExtendedReads;
	statisticsFiles << numberOfExtendedReads << " " << mean << " "
					<< stopNotPossibleExtensions << " " << stopRepetitiveSequence
					<< " " << stopLengthMaximumExceed << " " << stopMatePairFound
					<< " " << stopReadCycleFound << endl;

	OutputFile.close();
	statisticsFiles.close();
	if (layout) {
		layoutFile.close();
	}

	cout << "           ----------------------" << endl;
	cout << "number of extended reads is " << numberOfExtendedReads << endl;
	cout << "mean extensions for read " << mean << endl;
	cout << "           ----------------------" << endl;

	process_mem_usage(vm_usage, rss_usage);
	cout << "ordered cleaned: VM: " << vm_usage << "; RSS: " << rss_usage << endl;

	process_mem_usage(vm_usage, rss_usage);
	cout << "ordered deleted: VM: " << vm_usage << "; RSS: " << rss_usage << endl;

	time2 = clock();
	cout << "Wall time: " << (double) (time2 - start) / CLOCKS_PER_SEC << " s" << endl;

}

unsigned int FileRead(istream & is, vector<char> & buff) {
	is.read(&buff[0], buff.size());
	return is.gcount();
}

unsigned int CountLines(const vector<char> & buff, int sz) {
	int newlines = 0;
	const char * p = &buff[0];
	for (int i = 0; i < sz; i++) {
		if (p[i] == '\n') {
			newlines++;
		}
	}
	return newlines;
}

unsigned char * convert(const char * seq, size_t n) {
	unsigned char * conv = new unsigned char[n];

	for (size_t i = 0; i < n; i++)
		switch (seq[i]) {
		case 'A':
		case 'a':
			conv[i] = 1;
			break;
		case 'C':
		case 'c':
			conv[i] = 2;
			break;
		case 'G':
		case 'g':
			conv[i] = 3;
			break;
		case 'T':
		case 't':
			conv[i] = 4;
			break;
		default:
			conv[i] = 5;
		}
	return conv;
}

unsigned char * convert(unsigned int * read, unsigned short n) {

	unsigned char * conv = new unsigned char[n];
	unsigned int block = 0;
	unsigned int Mask = 0;
	Mask |= 1 << 31;
	Mask |= 1 << 30;
	unsigned int R = read[0];

	for (unsigned int i = 0; i < n; i++) {
		if (i % 16 == 0 && i > 0) {
			block++;
			R = read[block];
		}
		unsigned int c = (R & Mask) >> 30;
		R = R << 2;
		switch (c) {
		case 0:
			conv[i] = 1;
			break;
		case 1:
			conv[i] = 2;
			break;
		case 2:
			conv[i] = 3;
			break;
		case 3:
			conv[i] = 4;
			break;
		default:
			cout << "strange " << cout << endl;
		}
	}
	return conv;

}

void FilerLowQualityReadsForAssembly(const vector<string> fw_files, const vector<string> rv_files) {

	vector<string>::const_iterator iter_fw;
	vector<string>::const_iterator iter_rv;

	string fw_out = outputHeader + "_1.fastq";
	ofstream outputFileFW;
	outputFileFW.open(fw_out.c_str());

	string rv_out = outputHeader + "_2.fastq";
	ofstream outputFileRV;
	outputFileRV.open(rv_out.c_str());

	string unpaired = outputHeader + "_unpaired.fastq";
	ofstream outputFileUNPAIR;
	outputFileUNPAIR.open(unpaired.c_str());

	unsigned long int totalReadNum = 0;
	unsigned long int SucFiltReads = 0;
	unsigned long int UnsucFiltReads = 0;
	unsigned long int totalReadLength = 0;

	for (iter_fw = fw_files.begin(), iter_rv = rv_files.begin();
		 iter_fw != fw_files.end();
		 iter_fw++, iter_rv++) {

		Auto_Unzip input_file_fw(*iter_fw);
		Auto_Unzip input_file_rv(*iter_rv);
		istream & inputFileFW = input_file_fw.filtered();
		istream & inputFileRV = input_file_rv.filtered();

		Fastq read_fw;
		Fastq read_rv;

		Fastq::FASTQ_type type_fw = Fastq::check_FASTQ_type_file(
				iter_fw->c_str());

		read_fw.set_input_type(type_fw);
		read_rv.set_input_type(type_fw);

		while (not inputFileFW.eof() and not inputFileRV.eof()) {
			inputFileFW >> read_fw;
			inputFileRV >> read_rv;
			totalReadNum += 2;

			Mask masked_fw = Mask(read_fw);
			masked_fw.quality_trimming_CLC(min_phred_value_CLC, min_mean_quality, min_size);

			Mask masked_rv = Mask(read_rv);
			masked_rv.quality_trimming_CLC(min_phred_value_CLC, min_mean_quality, min_size);

			if (!(masked_fw.discarded || masked_rv.discarded
					|| masked_fw.low_quality || masked_rv.low_quality)) {
				masked_fw.extract_fasta_masked(read_fw);
				outputFileFW << read_fw;
				masked_rv.extract_fasta_masked(read_rv);
				outputFileRV << read_rv;
				SucFiltReads += 2;
				totalReadLength += (read_fw.get_sequence().length()
						+ read_rv.get_sequence().length());
			} else if (!(masked_fw.discarded || masked_fw.low_quality)) {
				masked_fw.extract_fasta_masked(read_fw);
				outputFileUNPAIR << read_fw;
				SucFiltReads++;
				totalReadLength += (read_fw.get_sequence().length());
			} else if (!(masked_rv.discarded || masked_rv.low_quality)) {
				masked_rv.extract_fasta_masked(read_rv);
				outputFileUNPAIR << read_rv;
				SucFiltReads++;
				totalReadLength += (read_rv.get_sequence().length());
			} else {
				UnsucFiltReads += 2;
			}
		}
	}

	cout << "total number of reads " << totalReadNum << endl;
	cout << "total number of successfully filtered reads " << SucFiltReads << endl;
	cout << "total number of discarded reads " << UnsucFiltReads << endl;
	cout << "total length of quality filtered reads " << totalReadLength << endl;

}

void ComputeTempReads(Hash* HashHead, Contig* contig, unsigned int j,
		unsigned int Extposition, unsigned int pos,
		vector<unsigned int*> &reads_for_ext, unsigned int read_length,
		unsigned int globalMismatch, bool seed_16mer, bool no_cycle,
		bool verbose) {

	// kmer control even for reads != seed
	if (not seed_16mer or HashHead->readsMulti[HashHead->HASHvalues[j].first].seed()) {
		Reads f = HashHead->readsMulti[HashHead->HASHvalues[j].first];
		string electedSequence = f.toString(HashHead->HASHvalues[j].second);
		unsigned int index = HashHead->HASHvalues[j].first;
		unsigned int localMismatch = (unsigned int) globalMismatch
				* (contig->ReturnContigLength() - pos - blockLength)
				/ read_length;
		if (contig->MaybeInsertRead(electedSequence, pos, Extposition, localMismatch, index, no_cycle)) {
			unsigned int* ii;
			ii = new unsigned int[3];
			ii[0] = j; //index of the read in HASHvalues
			ii[1] = Extposition; // position in the current extension
			ii[2] = pos; // position in the current contig
			if (verbose) {
				verb_printRead(electedSequence, ii[2]);
			}
			reads_for_ext.push_back(ii);
		}
	}
}

void ComputeExtReads(Hash* HashHead, Contig* contig, unsigned int* it,
		unsigned int read_length, unsigned int globalMismatch,
		const string & cons, unsigned int cons_start, Seeds* s_iter,
		vector<pair<unsigned int, bool> > & low_rep, bool verbose) {

	Reads f = HashHead->readsMulti[HashHead->HASHvalues[it[0]].first];
	string sequence = f.toString(HashHead->HASHvalues[it[0]].second);
	unsigned int index = HashHead->HASHvalues[it[0]].first;
	// mismatches = between read and consensus
	unsigned int mismatches = globalMismatch * (sequence.size() - blockLength) / read_length;

	if (contig->SelectReadsForConsensus(it[1], sequence, cons, cons_start, low_rep, mismatches)) {
		if (verbose) {
			verb_printRead(sequence, it[2]);
		}
		contig->InsertRead(sequence, it[2], it[1], index);
		HashHead->readsMulti[HashHead->HASHvalues[it[0]].first].setUsed();
		s_iter->add_read(it[0], it[2]);
		s_iter->set_leftmost(it[2] + 1);
	}
}

// TODO: Compute the branching point (it is NOT the first low-represented character!
//       There may be some reads overlapping the selected one but not matching it there)
unsigned int SelectRepresentativeRead(Hash* HashHead, const string & cons,
		unsigned int cons_start, vector<unsigned int*> &reads_for_ext,
		unsigned int first_pos, vector<pair<unsigned int, bool> > & low_rep) {

	unsigned int best_iter = 0, best_cover = 0, best_match = 0;
	for (unsigned int iter_reads = 0; iter_reads < reads_for_ext.size(); iter_reads++) {
		unsigned int match_low_pos = 0;
		Reads f = HashHead->readsMulti[HashHead->HASHvalues[reads_for_ext.at(iter_reads)[0]].first];
		string read_string = f.toString(HashHead->HASHvalues[reads_for_ext.at(iter_reads)[0]].second);
		unsigned short read_length = f.length();
		vector<pair<unsigned int, bool> >::iterator l = low_rep.begin();
		while (l != low_rep.end() and l->first < reads_for_ext.at(iter_reads)[1]) {
			l++;
		}
		while (l != low_rep.end() and l->first
				< reads_for_ext.at(iter_reads)[1] + read_string.length()) {
			match_low_pos += (read_string.at(l->first - reads_for_ext.at(iter_reads)[1]) == cons.at(l->first - cons_start));
			l++;
		}
		if (match_low_pos >= best_match and (match_low_pos > best_match or read_length >= best_cover)) {
			// it is better to select the longest read
			best_iter = iter_reads;
			best_match = match_low_pos;
			best_cover = read_length;
		}
	}
	return best_iter;
}

vector<unsigned int*> ComputeExtReadsBranch(Hash* HashHead, Contig* contig,
		vector<unsigned int*> &reads_for_ext, unsigned int read_length,
		unsigned int globalMismatch, int branch_mismatch,
		unsigned int first_pos, Seeds* s_iter, string cons,
		unsigned int cons_start, vector<pair<unsigned int, bool> > low_rep,
		bool verbose) {
	//cout << "AT THE BEGINNING, reads_for_ext.size(): " << reads_for_ext.size() << endl;
	if (low_rep.size() > 0) {
		unsigned int iter_reads = SelectRepresentativeRead(HashHead, cons, cons_start, reads_for_ext, first_pos, low_rep);
		unsigned int* first_read = reads_for_ext.at(iter_reads);
		//s_iter->add_read(first_read[0], first_read[2]);
		reads_for_ext.erase(reads_for_ext.begin() + iter_reads);
		Reads f1 = HashHead->readsMulti[HashHead->HASHvalues[first_read[0]].first];
		string first_read_string = f1.toString(HashHead->HASHvalues[first_read[0]].second);
		unsigned short first_read_length = f1.length();
		if (s_iter->leftmost() <= first_read[2]) {
			s_iter->set_leftmost(first_read[2] + 1);
		}
		if (verbose) {
			verb_printRead(first_read_string, first_read[2]);
			cout << "select overlapping reads..." << endl;
		}
		contig->InsertRead(first_read_string, first_read[2], first_read[1],
				HashHead->HASHvalues[first_read[0]].first);
		iter_reads = 0;
		bool first_read_added = false;
		while (iter_reads < reads_for_ext.size()) {
			if (s_iter->leftmost() <= reads_for_ext.at(iter_reads)[2]) {
				s_iter->set_leftmost(reads_for_ext.at(iter_reads)[2] + 1);
			}
			// compute mismatches
			Reads f2 = HashHead->readsMulti[HashHead->HASHvalues[reads_for_ext.at(iter_reads)[0]].first];
			string it_read_string = f2.toString(HashHead->HASHvalues[reads_for_ext.at(iter_reads)[0]].second);
			unsigned short it_read_length = f2.length();
			unsigned short max_start;
			if (first_read[1] <= reads_for_ext.at(iter_reads)[1]) {
				max_start = reads_for_ext.at(iter_reads)[1];
				if (not first_read_added) {
					s_iter->add_read(first_read[0], first_read[2]);
					first_read_added = true;
				}
			} else {
				max_start = first_read[1];
			}
			unsigned short min_end;
			if (first_read[1] + first_read_length <= reads_for_ext.at(iter_reads)[1] + it_read_length) {
				min_end = first_read_length + first_read[1] - 1;
			} else {
				min_end = reads_for_ext.at(iter_reads)[1] + it_read_length - 1;
			}
			if (min_end > max_start) {
				unsigned int mismatches = globalMismatch * (min_end - max_start + 1) / read_length;
				// check alignment of read (*it) versus first_read and we are happy if n^ of errors <= mismatches
				// a sufficient condition is that errors < low_rep.size()
				short read_ok = (low_rep.size() <= mismatches) ? 1
						: contig->SelectReadsForConsensusBranch(first_read_string, first_read[1],
																it_read_string, reads_for_ext.at(iter_reads)[1], max_start,
																min_end, low_rep, mismatches, branch_mismatch);
				if (read_ok == 1) {
					// OVERLAPPING READ
					if (verbose) {
						verb_printRead(it_read_string,
								reads_for_ext.at(iter_reads)[2]);
					}
					// insert read 
					unsigned int index = HashHead->HASHvalues[reads_for_ext.at(
							iter_reads)[0]].first;
					contig->InsertRead(it_read_string,
							reads_for_ext.at(iter_reads)[2],
							reads_for_ext.at(iter_reads)[1], index);
					HashHead->readsMulti[HashHead->HASHvalues[reads_for_ext.at(
							iter_reads)[0]].first].setUsed();
					// add read to the list of used ones
					s_iter->add_read(reads_for_ext.at(iter_reads)[0],
							reads_for_ext.at(iter_reads)[2]);
					// delete the current read as it will not be used for other branches
					delete[] reads_for_ext.at(iter_reads);
					reads_for_ext.erase(reads_for_ext.begin() + iter_reads);
				} else if (read_ok == -1) {
					// READ TO BE USED FOR A NEW BRANCH (read is very different from first read, maybe it belongs to another sequence)
					// TODO: controllare qui!!! Sembra che non venga generato nessun branch!!!
					iter_reads++;
				} else {
					// READ DISCARDED (it does not overlap the first read, but is not enough different from it)
					delete[] reads_for_ext.at(iter_reads);
					reads_for_ext.erase(reads_for_ext.begin() + iter_reads);
				}
			} else {
				//iter_reads++;
				// READ DISCARDED (ends too early)
				delete[] reads_for_ext.at(iter_reads);
				reads_for_ext.erase(reads_for_ext.begin() + iter_reads);
			}
		}
		delete[] first_read;
	} else {
		// if no low-rep positions occur, the reads could be immediately added
		for (unsigned int iter_reads = 0; iter_reads < reads_for_ext.size(); iter_reads++) {
			if (s_iter->leftmost() <= reads_for_ext.at(iter_reads)[2]) {
				s_iter->set_leftmost(reads_for_ext.at(iter_reads)[2] + 1);
			}
			Reads f2 = HashHead->readsMulti[HashHead->HASHvalues[reads_for_ext.at(iter_reads)[0]].first];
			string it_read_string = f2.toString(HashHead->HASHvalues[reads_for_ext.at(iter_reads)[0]].second);
			if (verbose) {
				verb_printRead(it_read_string, reads_for_ext.at(iter_reads)[2]);
			}
			unsigned int index = HashHead->HASHvalues[reads_for_ext.at(iter_reads)[0]].first;
			contig->InsertRead(it_read_string, reads_for_ext.at(iter_reads)[2],reads_for_ext.at(iter_reads)[1], index);
			HashHead->readsMulti[HashHead->HASHvalues[reads_for_ext.at(iter_reads)[0]].first].setUsed();
			// add read to the list of used ones
			s_iter->add_read(reads_for_ext.at(iter_reads)[0], reads_for_ext.at(iter_reads)[2]);
			// delete the current read as it will not be used for other branches
			delete[] reads_for_ext.at(iter_reads);
		}
		reads_for_ext.clear();
	}
	//cout << "AT THE END, reads_for_ext.size(): " << reads_for_ext.size() << endl;
	return reads_for_ext;
}

void verb_printConsensus(Contig* contig, unsigned int first_pos,
	unsigned int extThreshold, int slack, double perc_identity, bool branch) {
	unsigned int errors, cons_start, numfing;
	vector<pair<unsigned int, bool> > low_rep;
	// if perc < perc_identity, the char is not represented at all
	if (contig->ReturnOverlap() + slack > contig->ReturnContigLength()) {
		numfing = contig->ReturnContigLength();
	} else {
		numfing = contig->ReturnOverlap() + slack;
	}
	string cons;
	if (not branch) {
		cons = contig->contigExtension->returnConsensus(extThreshold, numfing,
				errors, perc_identity, low_rep, cons_start);
	} else {
		cons = contig->contigExtension->returnConsensusBranch(errors, low_rep,
				cons_start);
	}
	cout << "CONSENSUS SEQUENCE" << endl;
	if (cons.size() > 0) {
		for (unsigned int s = 0; s < first_pos + cons_start; s++) {
			cout << "*";
		}
		cout << cons << endl;
		unsigned int j = 0;
		unsigned int s = 0;
		while (s < first_pos + cons_start + cons.size()) {
			if (s < first_pos + cons_start) {
				cout << "*";
			} else if (s >= first_pos + cons_start and j < low_rep.size() and s
					== first_pos + low_rep[j].first) {
				cout << "*";
				j++;
			} else {
				cout << "X";
			}
			s++;
		}
		cout << endl;
		cout << "number of low represented characters: " << low_rep.size()
				<< endl;
	}
}

void verb_printRead(const string & electedSequence, unsigned int start) {
	for (unsigned int kk = 0; kk < start; kk++) {
		cout << "*";
	}
	cout << electedSequence << endl;
}
