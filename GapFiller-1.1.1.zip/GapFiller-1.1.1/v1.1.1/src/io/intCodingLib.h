//=======================================================================
//
// integer_coding_lib.h
//
// Copyright (C) 2002 Paolo Ferragina (http://www.di.unipi.it/~ferragin)
// Last revision: January 2002
//
// See the COPYRIGHT file for infos on the use of this software
//
//=======================================================================
#include <iostream>


// ***********************************************************************
// ************************** BASIC STUFF ********************************
// ***********************************************************************


// Definitions of useful constants
#define USIZE sizeof(unsigned)
#define BLOCK_SIZE 1000000
#define BYTES_TO_PRINT 7

// New data type definitions
typedef unsigned char uchar;
typedef unsigned int unsignedInt; // for compatibility issues



struct struct_buffer {
  uchar *pStartBuf;
  uchar *pCurPosBuf;
  int bit_offset;
  int current_size;
};


typedef struct struct_buffer buffer;


// inline functions declarations
__inline unsignedInt mylog2(unsignedInt n);



// ***********************************************************************
// ************************ BUFFER MANAGING ******************************
// ***********************************************************************


// Allocates memory for the buffer and cleans it
void init_buffer(buffer *pBuf);
void init_buffer(buffer *pBuf, int TextLength);

// Deletes buffer content and frees the allocated memory
void delete_buffer(buffer *pBuf);


// Rewinds the two iterators to buffer starting: They are the byte
// pointer and bit offset
void rewind_buffer(buffer *pBuf);


// Returns the number of bit not used into the buffer
int get_free_bit(buffer *pBuf);


// Returns the number of bits actually used by the buffer
int get_buffer_size(buffer *pBuf);


// Expands the buffer size to allow the storage of other BITNEEDED bits
void realloc_buffer(buffer *pBuf,int bitNeeded);


// This procedure return the number of bit used of the buffer,
// it doesn't return the memory allocated for the buffer.
int get_buffer_size(buffer *pBuf);	//return # bits


// Copies BIT_LEN bits from PMEM into the buffer PBUF
void load_buffer(buffer *pBuf,uchar *pMem,int bit_len);


// Copies in a new array, the current buffer content, and returns it
unsignedInt* get_buffer_content(buffer *pBuf);


// Moves the buffer iterator to point to the next byte (offset = 0)
void align_next_byte(buffer *pBuf);



// ***********************************************************************
// ********************** BUFFER I/O *************************************
// ***********************************************************************


// Stores the rightward BIT_LEN bits of SOURCE into buffer PBUF
void write_buffer(buffer *pBuf, unsignedInt source, int bit_len);


// Returns the length of the 0-run following the current position
// of the iterators in PBuf (moves the iterators)
int read_zero_number(buffer *pBuf);


// Reads LEN bits from the buffer and returns the value they represent
// It moves the buffer iterators
unsignedInt read_value(buffer *pBuf, int len);




//  *** GAMMA CODING, with updating of buffer iterators
unsignedInt read_gamma_code(buffer *pBuf);
void write_gamma_code(buffer *pBuf, unsignedInt n);



//  *** DELTA CODING, with updating of buffer iterators
unsignedInt read_delta_code(buffer *pBuf);
void write_delta_code(buffer *pBuf, unsignedInt n);


//  *** CONTINUATION_BIT CODING, with updating of buffer iterators
unsignedInt read_continuationbit_code(buffer *pBuf);
void write_continuationbit_code(buffer *pBuf, unsignedInt n);
int number_of_bytes_CB_code(unsignedInt n);

//  *** GOLOMB CODING, with updating of buffer iterators
void write_golomb_code(buffer *pBuf, unsignedInt n, unsignedInt k);
unsignedInt read_golomb_code(buffer *pBuf, unsignedInt k);


//  *** GAMMA_GOLOMB CODING, with updating of buffer iterators
unsignedInt read_gamma_golomb_code(buffer *pBuf, unsignedInt k);
void write_gamma_golomb_code(buffer *pBuf, unsignedInt n, unsignedInt k);



