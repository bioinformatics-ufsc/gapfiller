//=======================================================================
//
// integer_coding_lib.c
//
// Copyright 2002 Paolo Ferragina (http://www.di.unipi.it/~ferragin)
// Last revision: January 2002
//
//
// See the COPYRIGHT file for infos on the use of this software
//
//=======================================================================


#include "math.h"
#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include "intCodingLib.h"


// ***********************************************************************
// ********************** MATHEMATICAL FUNCTIONS *************************
// ***********************************************************************

// Computes the function log base 2
__inline unsignedInt mylog2(unsignedInt n)
{
  unsignedInt i=0;
  n >>= 1;

  for(; n != 0;   n >>= 1, i++) ;
  return(i);
}

// ***********************************************************************
// ********************** BUFFER BASIC FUNCTIONS *************************
// ***********************************************************************

// Allocates the memory for the buffer and cleans it
void init_buffer(buffer *pBuf)
{
	pBuf->pCurPosBuf=pBuf->pStartBuf=(uchar*)malloc(BLOCK_SIZE);

	if (!pBuf->pCurPosBuf) {	// malloc error
        printf("Insufficient memory");
		exit(1);
	}

	pBuf->current_size=BLOCK_SIZE;
	pBuf->bit_offset=0;

	// cleans the buffer
	memset(pBuf->pStartBuf,0,pBuf->current_size);
}


void init_buffer(buffer *pBuf,  int LengthText)
{

	pBuf->pCurPosBuf=pBuf->pStartBuf=(uchar*)malloc(LengthText);

	if (!pBuf->pCurPosBuf) {	// malloc error
        printf("Insufficient memory");
		exit(1);
	}

	pBuf->current_size=LengthText;

	pBuf->bit_offset=0;

	// cleans the buffer
	memset(pBuf->pStartBuf,0,pBuf->current_size);
}


// Deletes the buffer content and frees the allocated memory
void delete_buffer(buffer *pBuf)
{
  if (!pBuf) return;

  free(pBuf->pStartBuf);
  pBuf->pStartBuf=pBuf->pCurPosBuf=NULL;
  pBuf->bit_offset=pBuf->current_size=0;
}


// Rewinds the two iterators to buffer starting: They are the byte
// pointer and bit offset
void rewind_buffer(buffer *pBuf)
{
  pBuf->pCurPosBuf=pBuf->pStartBuf;
  pBuf->bit_offset=0;
}

// Returns the number of bit not used into the buffer
int get_free_bit(buffer *pBuf)
{
  int freeBitsByte = 8-pBuf->bit_offset;
  int freeBytes = pBuf->current_size-(pBuf->pCurPosBuf - pBuf->pStartBuf + 1);
  return(freeBitsByte + 8*freeBytes);
}


// Returns the number of bits actually used by the buffer
int get_buffer_size(buffer *pBuf)
{
  int usedBitsLastByte = pBuf->bit_offset;
  int usedBytes = pBuf->pCurPosBuf - pBuf->pStartBuf;


	return 8*usedBytes + usedBitsLastByte;
}


// Expands the buffer size to allow the storage of other BITNEEDED bits
void realloc_buffer(buffer *pBuf,int bitNeeded)
{

	int newSize,offCurPos;
	uchar *pTemp;

	if (!bitNeeded) bitNeeded=BLOCK_SIZE;

	offCurPos=pBuf->pCurPosBuf-pBuf->pStartBuf;
	newSize=pBuf->current_size+ BLOCK_SIZE; //(int)ceil((double)bitNeeded/8);

	//align the size to BLOCK_SIZE
	if (newSize%BLOCK_SIZE) {
		newSize+=BLOCK_SIZE-newSize%BLOCK_SIZE;
	}

	pTemp=(uchar*)malloc(newSize);

	if (!pTemp) {	// malloc error
        printf("Insufficient memory");
		exit(1);
	}

	memcpy(pTemp,pBuf->pStartBuf,pBuf->current_size);

	memset(pTemp+pBuf->current_size,0,newSize-pBuf->current_size);

	free (pBuf->pStartBuf);

	pBuf->pStartBuf=pTemp;

	pBuf->pCurPosBuf=pBuf->pStartBuf+offCurPos;

	pBuf->current_size=newSize;

}



// Copies BIT_LEN bits from PMEM into the buffer PBUF
void load_buffer(buffer *pBuf,uchar *pMem,int bit_len)
{
	int size;

	if (!pMem || !pBuf)
		exit(1);

	size=(int) floor((double)bit_len/8);

	if (!pBuf->bit_offset) {	// if byte aligned, use memcpy
		if (get_free_bit(pBuf)<bit_len) { // allocates new memory
			realloc_buffer(pBuf,bit_len);
		}
		memcpy(pBuf->pCurPosBuf,pMem,size);
		pBuf->pCurPosBuf+=size;
	}
	else { // not byte aligned
		while (size--) {
			write_buffer(pBuf,*pMem,8);
			pMem++;
		}
	}

	//copy manually the last byte to preserve the bit alignement
	if (bit_len%8) {
		write_buffer(pBuf,*pMem,bit_len%8);
	}
}

// Copies in a new array, the current buffer content, and returns it
unsignedInt* get_buffer_content(buffer *pBuf)
{
	int size;
	unsignedInt *pMem;

	if (!pBuf)
		exit(1);

	size=(int) ceil((double)get_buffer_size(pBuf)/8);

	pMem = (unsignedInt*)malloc (size);
	if (!pMem) {	// malloc error
        printf("Insufficient memory");
		exit(1);
	}

	memcpy(pMem,pBuf->pStartBuf,size);

	return pMem;
}

// Moves the buffer iterator to point to the next byte (offset is set to 0)
void align_next_byte(buffer *pBuf)
{
	if (!pBuf->bit_offset)	// already aligned
		return;

	if (get_free_bit(pBuf)<8) { // allocates new memory
		realloc_buffer(pBuf,0);	// 0 => autoincrement
	}

	pBuf->pCurPosBuf++;
	pBuf->bit_offset=0;
}



// ***********************************************************************
// ********************** BUFFER I/O *************************************
// ***********************************************************************



// Stores the rightward BIT_LEN bits of SOURCE into buffer PBUF
void write_buffer(buffer *pBuf, unsignedInt source, int bit_len)
{
  int writeable = bit_len + pBuf->bit_offset; // fictitious heading bits
  int right_shift, left_shift;
  int spacePresent;

  if(!bit_len) { return; }

  spacePresent=get_free_bit(pBuf);
  if (bit_len>spacePresent)
  {
      printf("going into  realloc_buffer\n");
      std::cout << "free spase " << spacePresent << "\n";
     std::cout << "buffer size " << get_buffer_size(pBuf) << "\n";
	  realloc_buffer(pBuf,bit_len-spacePresent);
  }

  if(writeable <= 8){ // write on one byte only
    (*pBuf->pCurPosBuf) |= (source << (8-writeable));
    pBuf->bit_offset = writeable % 8;
    if(!pBuf->bit_offset) pBuf->pCurPosBuf++;	// last byte was fitted

  } else {	//write on more than one byte


      do {

	right_shift = writeable-8;  // to take one byte
	(*pBuf->pCurPosBuf) |= (source >> right_shift); // leftward byte

	left_shift = 8*USIZE - right_shift; // cancels the written bits
	source = (source << left_shift) >> left_shift;

	pBuf->pCurPosBuf++;
	writeable -= 8;

      } while(writeable > 8);  // more than one byte to write

      (*pBuf->pCurPosBuf) |= (source << (8-writeable)); // the remaining bits
      pBuf->bit_offset = (pBuf->bit_offset + bit_len) % 8;
      if(!pBuf->bit_offset) pBuf->pCurPosBuf++;  // last byte was fitted
  }
}



// Returns the length of the 0-run following the current position
// of the iterators in PBuf (moves the iterators)
int read_zero_number(buffer *pBuf)
{

  uchar byte = (*pBuf->pCurPosBuf<< pBuf->bit_offset); // delete # offset
  int len=0;


  if(!byte) {
	  pBuf->pCurPosBuf++;
	  byte = *pBuf->pCurPosBuf;
	  len = 8- pBuf->bit_offset;
  }

  while(!byte){
    len += 8;
    pBuf->pCurPosBuf++;
    byte = *pBuf->pCurPosBuf;
  }

  while((byte & 0x80) != 128){
    byte <<= 1;
    len++;
  }

  pBuf->bit_offset = (pBuf->bit_offset + len) % 8;
  return(len);
}

// Reads LEN bits from the buffer (moves the iterators)
unsignedInt read_value(buffer *pBuf, int len)
{
  int i=0;
  unsignedInt value=0;
  int remaining;

  if (!pBuf->pCurPosBuf || !pBuf->pStartBuf) {
	printf ("Null pointer!");
	exit (1);
  }

  if (len==0) { return(0); }

  // select the rest of the current byte in the buffer
  value = ((*pBuf->pCurPosBuf) & (0xFF >> pBuf->bit_offset));
  if (pBuf->bit_offset+len <=8)
    {
      value >>= (8- (pBuf->bit_offset+len));	// get the next LEN bits
      pBuf->bit_offset = pBuf->bit_offset+len;
      if (!pBuf->bit_offset) pBuf->pCurPosBuf++;
      return(value);
    }

  i = (8- pBuf->bit_offset);
  pBuf->pCurPosBuf++;

  for(;(i+8)<len;i+=8)
    {
      value = (value<<8) | (*pBuf->pCurPosBuf);
      pBuf->pCurPosBuf++;
    }

  remaining = len-i;
  value <<= remaining;

  value |= ((*pBuf->pCurPosBuf) >> (8-remaining));  // take the last bits
  pBuf->bit_offset = (pBuf->bit_offset + len) % 8;
  if(!pBuf->bit_offset) pBuf->pCurPosBuf++;

  return(value);
}



// ***********************************************************************
// ********************** GAMMA CODING  **********************************
// ***********************************************************************

// Updates the buffer iterators
void write_gamma_code(buffer *pBuf, unsignedInt n)
{
  int len = mylog2(n);

  write_buffer(pBuf,0,len); // possibly len=0
  write_buffer(pBuf,n,len+1);
}

unsignedInt read_gamma_code(buffer *pBuf)
{

  int len;
  unsignedInt value;

  len = read_zero_number(pBuf);
  value = read_value(pBuf,len+1);

  return(value);
}


// ***********************************************************************
// ********************** DELTA CODING  **********************************
// ***********************************************************************

// Updates the buffer iterators
void write_delta_code(buffer *pBuf, unsignedInt n)
{
  unsignedInt len = (unsignedInt) mylog2(n);
  unsignedInt pow2 = (unsignedInt) pow(2, len);

  write_gamma_code(pBuf,len+1);
  write_buffer(pBuf,n-pow2,len);
}

unsignedInt read_delta_code(buffer *pBuf)
{

  unsignedInt len;
  unsignedInt value;
  unsignedInt pow2;

  len = read_gamma_code(pBuf) - 1;
  value = read_value(pBuf,len);
  pow2  = (unsignedInt) pow(2, len);

  return(pow2 + value);
}


// ***********************************************************************
// ***************** CONTINUATION_BIT CODING  ****************************
// ***********************************************************************


// Updates the buffer iterators
void write_continuationbit_code(buffer *pBuf, unsignedInt n)
{
  unsignedInt len = (unsignedInt) mylog2(n)+1;
  unsignedInt numByteLeft = (unsignedInt) ceil((double)len/7);
   unsignedInt right_shift,byte;

  while (numByteLeft)
  {
 	right_shift=(--numByteLeft)*7;

	byte = n>>right_shift;

	// if this byte isn't the last one, we set the first bit to 1
	if (right_shift)
	  byte|=128;

	write_buffer(pBuf,byte,8);

	if (!right_shift) break;

	// eliminating of the high order byte
	n%=1<<right_shift;

  }

}

int number_of_bytes_CB_code(unsignedInt n)
{
  unsignedInt len = (unsignedInt) mylog2(n)+1;
  unsignedInt numByteLeft = (unsignedInt) ceil((double)len/7);
  unsignedInt right_shift,byte;
  int numB=0;

  while (numByteLeft)
  {
 	numB++;
	right_shift=(--numByteLeft)*7;
	byte = n>>right_shift;
	// if this byte isn't the last one, we set the first bit to 1
	if (right_shift)
	  byte|=128;

	if (!right_shift) break;
	// eliminating of the high order byte
	n%=1<<right_shift;
  }
  return numB;

}


unsignedInt read_continuationbit_code(buffer *pBuf)
{
  int goOn=1;
   unsignedInt value;
  unsignedInt retVal=0;

  while(goOn)
  {
	value = read_value(pBuf,8);
	goOn=(value>127);

    value&=127;

	retVal=(retVal<<7)+value;

  }

  return retVal;
}

// ***********************************************************************
// ********************** GOLOMB CODING  *********************************
// ***********************************************************************


// Updates the buffer iterators
void write_golomb_code(buffer *pBuf, unsignedInt n, unsignedInt k)
{
  unsignedInt q = (unsignedInt)floor((n-1)/k);
  unsignedInt r = n - q*k - 1;
  unsignedInt log2_k = (unsignedInt) mylog2(k);
  unsignedInt pow2_k = (unsignedInt) pow(2, log2_k);
  unsignedInt d = 2*pow2_k - k;
  int i;

  // write the long sequences of zeros in groups of 32 bits
  for(i=0; i< floor(q/32); i++)
  write_buffer(pBuf, (unsignedInt) 0, 32);
  write_buffer(pBuf, (unsignedInt) 0, q % 32);

  // write the separating 1
  write_buffer(pBuf, 1, 1);

  if (r < d)
    write_buffer(pBuf,r,log2_k);
  else
    write_buffer(pBuf,r+d,log2_k+1);
}

unsignedInt read_golomb_code(buffer *pBuf, unsignedInt k)
{
  unsignedInt q,r;
  unsignedInt log2_k = (unsignedInt) mylog2(k);
  unsignedInt pow2_k = (unsignedInt) pow(2, log2_k);
  unsignedInt d = 2*pow2_k - k;

  q = read_zero_number(pBuf);
  read_value(pBuf,1); // skip the separating 1
  r = read_value(pBuf,log2_k);

  if (r < d)
    return(r+1+q*k);
  else
    {  // fetches one more bit
      r <<= 1;
      r |= read_value(pBuf,1);
      return(r+1+q*k-d);
    }
}


// ***********************************************************************
// ********************** GAMMA_GOLOMB CODING  ***************************
// ***********************************************************************

// Updates the buffer iterators
void write_gamma_golomb_code(buffer *pBuf, unsignedInt n, unsignedInt k)
{
  unsignedInt q = (unsignedInt) floor((n-1)/k);
  unsignedInt r = n - q*k - 1;
  unsignedInt log2_k = (unsignedInt) mylog2(k);
  unsignedInt pow2_k = (unsignedInt) pow(2, log2_k);
  unsignedInt d = 2*pow2_k - k;

  write_gamma_code(pBuf,q+1);

  if (r < d)
    write_buffer(pBuf,r,log2_k);
  else
    write_buffer(pBuf,r+d,log2_k+1);
}

unsignedInt read_gamma_golomb_code(buffer *pBuf, unsignedInt k)
{
  unsignedInt q,r;
  unsignedInt log2_k = (unsignedInt) mylog2(k);
  unsignedInt pow2_k = (unsignedInt) pow(2, log2_k);
  unsignedInt d = 2*pow2_k - k;

  q = read_gamma_code(pBuf)-1;
  r = read_value(pBuf,log2_k);

  if (r < d)
    return(r+1+q*k);
  else
    {  // fetches one more bit
      r <<= 1;
      r |= read_value(pBuf,1);
      return(r+1+q*k-d);
    }
}


