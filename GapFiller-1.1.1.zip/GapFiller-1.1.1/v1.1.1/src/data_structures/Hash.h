#ifndef HASH_H_
#define HASH_H_

#define _HASH_VERSION 0

#include <vector>
using namespace std;

#include "errors/Generic_Exception.h"
#include "errors/Incorrect_Format.h"
using namespace errors;

#include "common.h"

#include <boost/program_options.hpp>
namespace po = boost::program_options;

#include "io/Fastq.h"

#include <boost/lexical_cast.hpp>
#include "boost/random.hpp"
#include "boost/generator_iterator.hpp"

#include <iostream>
#include <fstream>

#include "io/intCodingLib.h"

#include "SetZ.h"
#include "GlobalToLocal.h"
#include "ResultItem.h"
#include "Reads.h"

typedef vector<ResultItem> Items;
typedef pair<unsigned int, unsigned int> sector;

typedef pair<unsigned int, bool> readOriented;

using namespace reads;

class Hash {
public:

	Hash();
	Hash(int k);
	Hash(int k, int blockLength);
	Hash(int k, int blockLength, int Zerrors, unsigned int numReads);
	~Hash();

	void init();
	void init_by_strand(unsigned int overlap);

	unsigned long int returnQ() {return this->q;}



	inline unsigned long int fill_right(unsigned long int Nq, char base);
	inline unsigned long int roll_right(char first_digit, unsigned long int Nq, char base);

	void insertRead(string read, unsigned int pos);
	unsigned long int ComputeFingerprint(unsigned int pos, bool orientation, unsigned int start);
	unsigned long int ComputeFingerprint(string contig, unsigned int start);

	int k;
	unsigned long int q;
	unsigned int blockLength;
	unsigned long int h;
	unsigned int numReads;

	int Zlength;
	unsigned long int *Z;
	int *errorsInZ;


	unsigned int * HASHcounter;
	readOriented * HASHvalues;
	Reads * readsMulti;
	//vector  < sector > * HASH;


	unsigned int MASK;

protected:
	size_t limit;


};




#endif /* HASH_H_ */
