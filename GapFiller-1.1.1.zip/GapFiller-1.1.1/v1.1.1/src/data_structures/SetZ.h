/*
 * SetZ.h
 *
 *  Created on: 29/lug/2010
 *      Author: cdf
 */

#ifndef SETZ_H_
#define SETZ_H_

#include <set>
using namespace std;

#include "errors/File_Not_Found.h"
using namespace errors;

class SetZ {
public:
	SetZ() {}
	void initZ(int errors, int block, unsigned long int q);
	~SetZ();
	inline int returnIndex(int err) { return this->errorsInsetZ[err]; }
	inline unsigned long int returnVal(int idx) { return this->Zarray[idx]; }
	inline int returnSize() { return this->size; }

	void save(const char * filename) throw (File_Not_Found);
	void load(const char * filename) throw (File_Not_Found);

private:
	struct Z {
		unsigned long int z;
		int error;

		bool operator < (Z  z2) const {
			int e1=this->error;
		    int e2=z2.error;
		   	unsigned long int zz1=this->z;
			unsigned long int zz2=z2.z;

			return ( (e1 < e2 ) or  (e1==e2 and  zz1 < zz2 )) ? true:false;
		}

	};

	unsigned long int *Zarray;
	int * errorsInsetZ;
	int block;
	int errors;
	unsigned long int q;
	int size;
	// vectors for the construction of the set
	int u[1000], t[1000], i[1000];
	set < Z > belongsZ0;
	set < Z >::const_iterator iterZ0;
	void backtrackZ(int j, int D);

};


#endif /* SETZ_H_ */
