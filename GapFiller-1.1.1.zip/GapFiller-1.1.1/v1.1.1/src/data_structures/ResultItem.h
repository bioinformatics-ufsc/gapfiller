/*
 * ResultItem.h
 *
 *  Created on: 29/lug/2010
 *      Author: cdf
 */

#ifndef RESULTITEM_H_
#define RESULTITEM_H_

class ResultItem {
public:

	struct less {
		bool operator()(const ResultItem & hit1, const ResultItem & hit2) {
			int p1=hit1.GlobalPosition;
			int p2=hit2.GlobalPosition;
			int e1=hit1.errors;
			int e2=hit2.errors;

			return ( e1<e2 or (e1==e2 and p1<p2) or (e1==e2 and p1==p2 and hit1.strand < hit2.strand)) ? true:false;
		}
	};

	struct equal {
		bool operator()(const ResultItem & hit1, const ResultItem & hit2) {
			return ( hit1.GlobalPosition==hit2.GlobalPosition and hit1.strand == hit2.strand) ? true:false;
		}
	};

	int GlobalPosition; // position in the concatenated reference
	int errors; // number of errors
	bool strand; // strand : true=+, false=-
};

#endif /* RESULTITEM_H_ */
