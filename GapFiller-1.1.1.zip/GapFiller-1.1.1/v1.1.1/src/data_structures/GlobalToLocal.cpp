/*
 * GlobalToLocal.cpp
 *
 *  Created on: 29/lug/2010
 *      Author: cdf
 */

#include "GlobalToLocal.h"

GlobalToLocal::GlobalToLocal() {
	Contigs = 0;
}

GlobalToLocal::GlobalToLocal(int numContig) {
	Contigs = numContig;
	startPositions = new int[numContig];
	endPositions = new int[numContig];
	contigsNames = new string[numContig];
}

GlobalToLocal::GlobalToLocal(const GlobalToLocal &GTL) {
	Contigs = GTL.Contigs;
	if (Contigs > 0) {
		startPositions = new int[Contigs];
		endPositions = new int[Contigs];
		contigsNames = new string[Contigs];
		for (int i = 0; i < Contigs; i++) {
			startPositions = GTL.startPositions;
			endPositions = GTL.endPositions;
			contigsNames = GTL.contigsNames;
		}
	}
}

GlobalToLocal & GlobalToLocal::operator=(const GlobalToLocal & GTL) {
	if (this != &GTL) {
		if (Contigs > 0) {
			delete [] startPositions;
			delete [] endPositions;
			delete [] contigsNames;
		}
		Contigs = GTL.Contigs;
		if (Contigs > 0) {
			startPositions = new int[Contigs];
			endPositions = new int[Contigs];
			contigsNames = new string[Contigs];
			for (int i = 0; i < Contigs; i++) {
				startPositions[i] = GTL.startPositions[i];
				endPositions[i] = GTL.endPositions[i];
				contigsNames[i] = GTL.contigsNames[i];
			}
		}
	}
	return *this;
}

int GlobalToLocal::searchContig(int GlobalCoordinate) {
	int min = 0;
	int max = Contigs-1;
	int i;
	while (min <= max) {
		i = (min+max)/2;
		if (GlobalCoordinate > endPositions[i])
				min = i+1;
		else if (GlobalCoordinate < startPositions[i])
			max = i-1;
		else
			return i;
	}
	cerr << "Position \"" << GlobalCoordinate << "\" not found for GlobalToLocal::searchContig(int position)";
	std::exit(2);
}

