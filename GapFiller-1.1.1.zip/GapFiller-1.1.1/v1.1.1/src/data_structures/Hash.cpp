#include "Hash.h"


//BOOST_CLASS_VERSION(Hash, _HASH_VERSION);

Hash::Hash() {
	Z = NULL;
	errorsInZ = NULL;
}

Hash::Hash(int k) {

	Z = NULL;
	errorsInZ = NULL;

	this->k=k;
	this->q =(1 << (2 * this->k)) - 1;
	this->blockLength=10;
	int tt=blockLength;
	this->h=1;
	while(tt>1) {
		this->h= (4*this->h)%q;
		tt--;
	}
	limit =   512*1024*1024;

}

Hash::Hash(int k, int blockLength) {
	Z = NULL;
	errorsInZ = NULL;

	this->k=k;
	this->q=0;
	for(int i = 0; i < 2*k; i++) {
		this->q |= 1 << i;
		//cout << i <<" "<< this->q << "\n";
	}

	this->blockLength=blockLength;
	int tt=blockLength;
	this->h=1;
	while(tt>1) {
		this->h= (4*this->h)%q;
		tt--;
	}
	limit =   512*1024*1024;

}


Hash::Hash(int k, int blockLength, int Zerrors, unsigned int numReads) {

	this->numReads = numReads;
	this->k=k;
	this->q=0;
	for(int i = 0; i < 2*k; i++) {
		this->q |= 1 << i;
	}

	SetZ *Zset = new SetZ();
	Zset->initZ(Zerrors, k, q);
	Zlength = Zset->returnSize();
	Z = new unsigned long int[Zset->returnSize()];
	errorsInZ = new int[3];
	for(int i = 0 ; i< Zset->returnSize(); i++) {
		Z[i] = Zset->returnVal(i);
	}
	for(int i=0; i<3; i++) {
		errorsInZ[i] = Zset->returnIndex(i);
	}


	this->blockLength=blockLength;
	int tt=blockLength;
	this->h=1;
	while(tt>1) {
		this->h= (4*this->h)%q;
		tt--;
	}
	limit =   512*1024*1024;


	HASHcounter = new unsigned int [q];
	for(unsigned long int i =0; i < q; i++) {
		HASHcounter[i] = 0;
	}
	HASHvalues = new readOriented [numReads*2];


	// create HASH TABLE as an array of vector
/*
	HASH = new vector <sector>[q];
	for(unsigned long int i=0; i < q; i++) {
		HASH[i]= vector <sector>();
	}
*/
	readsMulti = new Reads[numReads];

}

void Hash::init() {
	unsigned long int fp;
	for(unsigned int i = 0; i < numReads; i++) {
		fp = ComputeFingerprint(i, true, 0);  // compute fingerprint for original read
//		cout << fp << " ";
		HASHcounter[fp]++;
		fp = ComputeFingerprint(i, false, 0); // reverse complemented
//		cout << fp << "\n";
		HASHcounter[fp]++;
	}
	unsigned int t1 = HASHcounter[0];
	HASHcounter[0]=0;
	for(unsigned int i = 1; i < q; i++) {
		int t2 = HASHcounter[i];
		HASHcounter[i] = HASHcounter[i-1] + t1;
		t1 = t2;
	}
//	LAST = HASHcounter[q-1] + t1; i dont need it the number of computed fingerpringts is well known

	for(unsigned int i = 0; i < numReads; i++) {
		fp = ComputeFingerprint(i, true, 0);
		readOriented r1 =  readOriented(i, true);
		HASHvalues[HASHcounter[fp]] = r1;
		HASHcounter[fp]++;
		fp = ComputeFingerprint(i, false, 0);
		readOriented r2 =  readOriented(i, false);
		HASHvalues[HASHcounter[fp]] = r2;
		HASHcounter[fp]++;
	}

	for(unsigned int i=q; i > 0 ; i--) {
		HASHcounter[i]= HASHcounter[i-1];
	}
	HASHcounter[0] = 0;
}


void Hash::init_by_strand(unsigned int overlap) {
	unsigned long int fp;
	for(unsigned int i = 0; i < numReads; i++) {
		fp = ComputeFingerprint(i, true, 0);  // compute fingerprint for original read
//		cout << fp << " ";
		HASHcounter[fp]++;
		fp = ComputeFingerprint(i, false, overlap-blockLength); // reverse complemented
//		cout << fp << "\n";
		HASHcounter[fp]++;
	}
	unsigned int t1 = HASHcounter[0];
	HASHcounter[0]=0;
	for(unsigned int i = 1; i < q; i++) {
		int t2 = HASHcounter[i];
		HASHcounter[i] = HASHcounter[i-1] + t1;
		t1 = t2;
	}
//	LAST = HASHcounter[q-1] + t1; i dont need it the number of computed fingerpringts is well known

	for(unsigned int i = 0; i < numReads; i++) {
		fp = ComputeFingerprint(i, true, 0);
		readOriented r1 =  readOriented(i, true);
		HASHvalues[HASHcounter[fp]] = r1;
		HASHcounter[fp]++;
		fp = ComputeFingerprint(i, false, overlap-blockLength);
		readOriented r2 =  readOriented(i, false);
		HASHvalues[HASHcounter[fp]] = r2;
		HASHcounter[fp]++;
	}

	for(unsigned int i=q; i > 0 ; i--) {
		HASHcounter[i]= HASHcounter[i-1];
	}
	HASHcounter[0] = 0;
}



Hash::~Hash() {
	if (Z != NULL)
		delete [] Z;
	if (errorsInZ != NULL)
		delete [] errorsInZ;
//	if (HASH != NULL)
//		delete HASH;

}

inline unsigned long int Hash::fill_right(unsigned long int Nq, char base) {
	return ((Nq << 2) + base) % q ;
}

inline unsigned long int Hash::roll_right( char first_digit, unsigned long int Nq, char base) {
	return  ((q + Nq - first_digit * h) * 4 + base) % q;

}

void Hash::insertRead(string read, unsigned int pos) {
	unsigned long int fingerprint = 0;
	for (unsigned int j = 0; j< blockLength; j++) {
		char c=0;
		switch(read.at(j)) {
			case 'a' : case 'A' : c=0; break;
			case 'c' : case 'C' : c=1; break;
			case 'g' : case 'G' : c=2;break;
			case 't' : case 'T' : c=3;break;
		}
		fingerprint = fill_right(fingerprint, c);
	}

/*
	if(HASH[fingerprint].empty()) {
		//cout << "\t" << fingerprint << " empty\n";
		sector s =  sector(pos, pos);
		HASH[fingerprint].push_back( s );
	} else {
		if(HASH[fingerprint][HASH[fingerprint].size()-1].second == pos -1) {
			//cout << "extend\n";
			HASH[fingerprint][HASH[fingerprint].size()-1].second++;
		} else {
			//cout << "new\n";
			sector s =  sector(pos, pos);
			HASH[fingerprint].push_back( s );
		}
	}
*/
}


unsigned long int Hash::ComputeFingerprint(unsigned int pos, bool orientation, unsigned int start) {
	string read = readsMulti[pos].toString(orientation);
	unsigned long int fingerprint = 0;
	for (unsigned int j = start; j< start + blockLength && j< read.length(); j++) {
		char c=0;
		switch(read.at(j)) {
		case 'a' : case 'A' : c=0; break;
		case 'c' : case 'C' : c=1; break;
		case 'g' : case 'G' : c=2;break;
		case 't' : case 'T' : c=3;break;
		}
		fingerprint = fill_right(fingerprint, c);
	}
	return fingerprint;

}


unsigned long int Hash::ComputeFingerprint(string contig, unsigned int start) {

	unsigned long int fingerprint = 0;
	for (unsigned int j = start; j< start + blockLength && j< contig.length(); j++) {
		char c=0;
		switch(contig.at(j)) {
		case 'a' : case 'A' : c=0; break;
		case 'c' : case 'C' : c=1; break;
		case 'g' : case 'G' : c=2;break;
		case 't' : case 'T' : c=3;break;
		}
		fingerprint = fill_right(fingerprint, c);
	}
	return fingerprint;

}


