#include "Reads.h"



namespace reads
{





Reads::~Reads() {
	//delete readP;
	//delete readM;
}



Reads::Reads(const string & s, bool cs) {

	//save read length
	this->information = s.length(); //(uint8_t)s.length();

	//set bit for first mate
	if(cs) {
		setBit(this->information, 16);
	} else {
		clearBit(this->information, 16);
	}
	//set read to unused
	clearBit(this->information, 17);
	// set bit to not Seed
	clearBit(this->information, 18);

	unsigned short int bufferREAD_length = ceil((s.length())/(float)16);
	read = new unsigned int[bufferREAD_length];
	memset(read , 0 , bufferREAD_length);
	int actualByte = 0;
	int actualBit = 0;

	for (unsigned int i = 0; i < s.length() ; i++) {
		switch (s.at(i)) {
		case 'A' : case 'a' : read[actualByte] &= ~(1 << (31-actualBit)); read[actualByte] &= ~(1 << (31-(actualBit+1))); break;
		case 'C' : case 'c' : read[actualByte] &= ~(1 << (31-actualBit)); read[actualByte] |= (1 << (31-(actualBit+1)));  break;
		case 'G' : case 'g' : read[actualByte] |= (1 << (31-actualBit)); read[actualByte] &= ~(1 << (31-(actualBit+1)));   break;
		case 'T' : case 't' : read[actualByte] |= (1 << (31-actualBit)); read[actualByte] |= (1 << (31-(actualBit+1)));  break;
		default : read[actualByte] &= ~(1 << (31-actualBit)); read[actualByte] &= ~(1 << (31-(actualBit+1))); break;
		}
		actualBit+=2;
		if(actualBit == 32) {
			actualByte++;
			actualBit=0;
		}
	}

	string sequence = reverse_complement_standalone_str(s);
	readRC = new unsigned int[bufferREAD_length];
	memset(readRC , 0 , bufferREAD_length);
	actualByte = 0;
	actualBit = 0;

	for (unsigned int i = 0; i < sequence.length() ; i++) {
		switch (sequence.at(i)) {
		case 'A' : case 'a' : readRC[actualByte] &= ~(1 << (31-actualBit)); readRC[actualByte] &= ~(1 << (31-(actualBit+1))); break;
		case 'C' : case 'c' : readRC[actualByte] &= ~(1 << (31-actualBit)); readRC[actualByte] |= (1 << (31-(actualBit+1)));  break;
		case 'G' : case 'g' : readRC[actualByte] |= (1 << (31-actualBit)); readRC[actualByte] &= ~(1 << (31-(actualBit+1)));   break;
		case 'T' : case 't' : readRC[actualByte] |= (1 << (31-actualBit)); readRC[actualByte] |= (1 << (31-(actualBit+1)));  break;
		default : readRC[actualByte] &= ~(1 << (31-actualBit)); readRC[actualByte] &= ~(1 << (31-(actualBit+1))); break;
		}
		actualBit+=2;
		if(actualBit == 32) {
			actualByte++;
			actualBit=0;
		}
	}

}

Reads::Reads(const Reads &r) {
	read = r.read;
	readRC = r.readRC;
	information = r.information;
}

Reads & Reads::operator=(const Reads & r) {
	if (this != &r) { // protect against invalid self-assignment
		this->read = r.read;
		this->readRC =r.readRC;
		this->information = r.information;

	}
	return *this;
}

unsigned short int Reads::length() {
//	cout << information << "\n";
	return (unsigned short int)(  uint8_t(this->information >> 8) << 8  | uint8_t(this->information ) );

}

bool Reads::firstMate() {
	return returnBit(this->information, 16);
}

bool Reads::used() {
	return returnBit(this->information, 17);
}

void Reads::setUsed() {
	setBit(this->information, 17);
}

bool Reads::seed() {
	return returnBit(this->information, 18);
}

void Reads::setSeed() {
	setBit(this->information, 18);
}

void Reads::setCoverage(unsigned int coverage) {
	if(coverage >= 65536) {
		coverage = 65535; // high coverage do not store it is high anyway
	}
	this->cov = coverage;
//	this->information |= (coverage << 24);
}

unsigned int Reads::coverage() {
	return this->cov;
//	return uint8_t(this->information >> 24);
}


string  Reads::toString(bool P) {
	unsigned int Mask = 0;
	unsigned int  block= 0;
	Mask |= 1 << 31;
	Mask |= 1 << 30;

	string out="";

	unsigned int R;
	P ? R = read[0] :	R = readRC[0];

	for(unsigned int i =0 ; i < length() ; i++) {
		if(i%16 == 0 && i>0) {
			block++;
			P ? R = read[block] :	R = readRC[block];
		}
		unsigned int c = (R & Mask) >> 30;
		R = R << 2;
		switch(c) {
			case 0: out.append("A"); break;
			case 1: out.append("C"); break;
			case 2: out.append("G"); break;
			case 3: out.append("T"); break;
			default: cout << "strange "<< cout << "\n";
		}
	}

	return out;
}


Seeds::Seeds(){
	this->_seed_length = 0;
	this->_seed_mate_length = 0;
	this->_leftmost = 0;
}

Seeds::Seeds(const string & seed, const string & mate){
	this->_seed_string = seed;
	this->_seed_mate_string = mate;
	this->_seed_length = seed.size();
	this->_seed_mate_length = mate.size();
	this->_leftmost = 0;
}


Seeds::Seeds(const string & seed, const string & mate,
			const vector < pair <unsigned int, unsigned int> > & reads){
	this->_seed_string = seed;
	this->_seed_mate_string = mate;
	this->_seed_length = seed.size();
	this->_seed_mate_length = mate.size();
	this->_extension_reads = reads;
	this->_leftmost = 0;
}


Seeds::~Seeds(){
	// do nothing
}


void Seeds::add_read(unsigned int index, unsigned int position){
	pair <unsigned int, unsigned int> temp;
	temp.first = index;
	temp.second = position;
	this->_extension_reads.push_back(temp);
}


void Seeds::set_seed(const string & seed, const string & mate, const vector < pair <unsigned int, unsigned int> > & reads) {
	this->_seed_string = seed;
	this->_seed_mate_string = mate;
	this->_seed_length = seed.size();
	this->_seed_mate_length = mate.size();
	this->_extension_reads = reads;
}


Extension::Extension() {
	this->farthest = 0;
	this->size = 200;
	this->A = new unsigned int[this->size];
	memset(this->A,0, (this->size)*sizeof(int));
	this->C = new unsigned int[this->size];
	memset(this->C,0, (this->size)*sizeof(int));
	this->G = new unsigned int[this->size];
	memset(this->G,0, (this->size)*sizeof(int));
	this->T = new unsigned int[this->size];
	memset(this->T,0, (this->size)*sizeof(int));
	this->Total = new unsigned int[this->size];
	memset(this->Total,0, (this->size)*sizeof(int));
}


Extension::Extension(unsigned  int size) {
	this->farthest = 0;
	this->size = size;
	this->A = new unsigned int[this->size];
	memset(this->A,0, (this->size)*sizeof(int));
	this->C = new unsigned int[this->size];
	memset(this->C,0, (this->size)*sizeof(int));
	this->G = new unsigned  int[this->size];
	memset(this->G,0, (this->size)*sizeof(int));
	this->T = new unsigned  int[this->size];
	memset(this->T,0, (this->size)*sizeof(int));
	this->Total = new unsigned int[this->size];
	memset(this->Total,0, (this->size)*sizeof(int));
}


Extension::~Extension() {
	if (A != NULL)
		delete [] A;
	if (C != NULL)
		delete [] C;
	if (G != NULL)
		delete [] G;
	if (T != NULL)
		delete [] T;
	if (Total != NULL)
		delete [] Total;
}


void Extension::insertRead(unsigned int start , const string & read) {
	for(unsigned int i = 0; i< read.length(); i++) {
		switch(read.at(i)) {
		case 'A': case 'a': A[start]++; Total[start]++; start++; break;
		case 'C': case 'c': C[start]++; Total[start]++; start++; break;
		case 'G': case 'g': G[start]++; Total[start]++; start++; break;
		case 'T': case 't': T[start]++; Total[start]++; start++; break;
		}
	}
	if(start > farthest ) {
		this->farthest = start;
	}
}


string Extension::returnConsensus() {
	string consensus="";
	for(unsigned  int i=0; i< this->farthest; i++) {
		if(Total[i]>0) {
			consensus.append(returnMAX(A[i],C[i],G[i],T[i]));
		}
	}
	return consensus;
}

string Extension::returnConsensus(unsigned int thr,unsigned int numFingerprints, unsigned int & errors, double perc_identity, 
								  vector< pair<unsigned int, bool> > &low_represented, unsigned int &cons_start) {
	string consensus="";
	unsigned int i=0;
	while(Total[i]==0 && i < this->farthest ) {
		i++;
	}
	cons_start = i;
	while((Total[i] >= thr || i < numFingerprints) && i < this->farthest) {
		consensus.append(returnMAX(A[i],C[i],G[i],T[i]));
		bool represented;
		if (checkRepeatStatus(A[i],C[i],G[i],T[i], perc_identity, represented)){
			pair <unsigned int, bool> el = make_pair(i, represented);
			low_represented.push_back(el);
			errors++;
		}
		i++;
	}
	return consensus;
}

string Extension::returnConsensusBranch (unsigned int &errors, vector< pair<unsigned int, bool> > &low_represented, unsigned int &cons_start) {
	string consensus="";
	unsigned int i=0;
	while(Total[i]==0 && i < this->farthest ) {
		i++;
	}
	cons_start = i;
	while(i < this->farthest) {
		bool represented;
		consensus.append(returnMAX(A[i],C[i],G[i],T[i],represented));
		if (not represented){
			pair <unsigned int, bool> el = make_pair(i, false);
			low_represented.push_back(el);
			errors++;
		}
		i++;
	}
	return consensus;
}

unsigned int Extension::returnFirstPosition() {
	unsigned int i=0;
	while(Total[i] == 0 && i < farthest) {
		i++;
	}
	if(i== farthest)
		return 0;

	return i;

}


int Extension::checkRepeatStatus(int a, int c, int g, int t, double perc_identity, bool& represented) {

	float total = a + c + g + t;

	int max = a;
	int id = 0;
	if(c > max) {max = c; id = 1;}
	if(g > max) {max = g; id = 2;}
	if(t > max) {max = t; id = 3;}

	float res = max/total;
	if (res < perc_identity){ // distinguish low represented chars from those not represented at all
		represented = false;
		if (max == 1){
			return 1;
		}
	} else {
		represented = true;
	}

	// for every percentage < 1 and >= perc_identity a char is considered to be low represented
	// at least 2 chars different from consensus, otherwise it's a sequencing error
	if(total-max > 1) { // try to distinguish sequencing errors from SNPs
	//if (represented and total-max > 1){
		int second_max = 0;
		if ((a != max or id != 0) and a > second_max) {second_max = a;}
		if ((c != max or id != 1) and c > second_max) {second_max = c;}
		if ((g != max or id != 2) and g > second_max) {second_max = g;}
		if ((t != max or id != 3) and t > second_max) {second_max = t;}
		if (second_max > 1){ // try to distinguish sequencing errors from SNPs
			return 1;
		}
	}

	return 0;
}


string Extension::returnMAX(int a, int c, int g, int t) {
	int max = 0;
	if(a>max) {max =a;}
	if(c>max) {max =c;}
	if(g>max) {max =g;}
	if(t>max) {max =t;}

	if(max==a) {
		return "A";
	} else if(max==c) {
		return "C";
	} else if(max==g) {
		return "G";
	} else if(max==t) {
		return "T";
	}
	return "";
}


string Extension::returnMAX(int a, int c, int g, int t, bool &represented) {
	int max = 0;
	if(a>max) {max =a;}
	if(c>max) {max =c;}
	if(g>max) {max =g;}
	if(t>max) {max =t;}
	represented = (max == a+c+g+t);

	if(max==a) {
		return "A";
	} else if(max==c) {
		return "C";
	} else if(max==g) {
		return "G";
	} else if(max==t) {
		return "T";
	}
	return "";
}

Contig::Contig() {
	this->contig ="";
	this->extensionLength = 200;
	this->ContigStatus = Continue;
}

Contig::Contig(const string & contig, unsigned int contigNum, unsigned int extensionLength, unsigned long int q,
		unsigned long int h, unsigned int BL, unsigned int overlap, unsigned int numFingerprints) {

	this->q = q;
	this->h = h;
	this->BL = BL;
	this->overlap = overlap;
//	this->clustRepThr = clustRepThr;

	this->numFingerprints = numFingerprints;
	this->contig= contig;
	this->contigNum = contigNum;
	this->extensionLength = extensionLength;

	this->ContigStatus = Continue;
}

Contig::Contig(const string &contig, const set <unsigned int> &reads_used, unsigned int contigNum, unsigned int extensionLength, unsigned long int q,
		unsigned long int h, unsigned int BL, unsigned int overlap, unsigned int numFingerprints) {

	this->q = q;
	this->h = h;
	this->BL = BL;
	this->overlap = overlap;
//	this->clustRepThr = clustRepThr;

	this->numFingerprints = numFingerprints;
	this->contig= contig;
	this->InsertedReads = reads_used;
	this->contigNum = contigNum;
	this->extensionLength = extensionLength;

	this->ContigStatus = Continue;
}


Contig::~Contig() { }


void Contig::InitializeExtension() {
	this->contigExtension = new Extension(this->extensionLength);
	this->firstExtendedPosition = 0;
	this->AreaWithNoFing = contig.length() - overlap;
}


void Contig::DeleteExtension() {
	if(this->contigExtension != NULL) {
		delete this->contigExtension;
	}
	this->firstExtendedPosition = 0;
}


inline unsigned long int Contig::fill_right(unsigned long int Nq, char base) {
	return ((Nq << 2) + base) % q ;
}

inline unsigned long int Contig::roll_right( char first_digit, unsigned long int Nq, char base) {
	return  ((q + Nq - first_digit * h) * 4 + base) % q;

}

unsigned long int Contig::ComputeFingerprint(int n) {
	unsigned int start = contig.length() - overlap - n;
	unsigned long int fingerprint = 0;
	for (unsigned int j = start; j < start + BL; j++) {
		char c=0;
		switch(contig.at(j)) {
		case 'a' : case 'A' : c=0; break;
		case 'c' : case 'C' : c=1; break;
		case 'g' : case 'G' : c=2;break;
		case 't' : case 'T' : c=3;break;
		}
		fingerprint = fill_right(fingerprint, c);
	}
	return fingerprint;

}

unsigned long int Contig::ComputeFingerprintForCheck(unsigned int s) {

	unsigned int start = s;
	unsigned long int fingerprint = 0;
	unsigned int end = (start + BL < contig.size()) ? start + BL : contig.size();
	for (unsigned int j = start; j < end; j++) {
		char c=0;
		switch(contig.at(j)) {
		case 'a' : case 'A' : c=0; break;
		case 'c' : case 'C' : c=1; break;
		case 'g' : case 'G' : c=2;break;
		case 't' : case 'T' : c=3;break;
		}
		fingerprint = fill_right(fingerprint, c);
	}
	return fingerprint;
}


bool Contig::MaybeInsertRead(const string & read, unsigned int start, unsigned int extStart, unsigned int localMismatches,
		unsigned int readPosition, bool no_cycle) {
	unsigned int mismatches=0;
	unsigned int el=0;

	// new: controllo di TUTTO l'overlap
	unsigned int numfing = (this->ReturnContigLength() - start > read.length()) ? read.length() : this->ReturnContigLength()-start;

	//for(unsigned int st= start ; st < start + BL ; st++) {
	for(unsigned int st = start; st < start + numfing; st++) {
		if(contig.at(st) != read.at(el)) {
			mismatches++;
		}
		el++;
	}
	if(mismatches <= localMismatches) {
		this->contigExtension->insertRead(extStart, read);
		/*
		if(this->firstExtendedPosition == 0) {
			this->firstExtendedPosition = start;
		}
		*/
		this->Reads.push_back(readPosition);

		if(not no_cycle and not this->InsertedReads.insert(readPosition).second) {
			//if element already present
			this->ContigStatus = ReadCycleFound;
		}
		return true;
	}
	return false;
}


void Contig::InsertRead(const string & read, unsigned int start, unsigned int extStart, unsigned int readPosition) {
	this->contigExtension->insertRead(extStart, read);
	this->Reads.push_back(readPosition);
	return;
}


unsigned short Contig::Mismatches(const string & read, unsigned int start, unsigned int extStart) {
	unsigned short mismatches=0;
	unsigned int el=0;

	// new: controllo di TUTTO l'overlap
	unsigned int numfing = (this->ReturnContigLength()-start > read.length()) ? read.length() : this->ReturnContigLength()-start;

	//for(unsigned int st= start ; st < start + BL ; st++) {
	for(unsigned int st= start ; st < start + numfing; st++) {
		if(contig.at(st) != read.at(el)) {
			mismatches++;
		}
		el++;
	}
	return mismatches;
}

/*
bool Contig::MaybeReadExt(unsigned int start, string best_read, unsigned int best_extStart,
						  string read, unsigned int extStart, unsigned int extMismatches, unsigned int readPosition) {

	unsigned int mismatches=0;

	unsigned int max_start;
	if (best_extStart >= extStart) {
		max_start = best_extStart;
	} else {
		max_start = extStart;
	}

	unsigned int min_end;
	if (best_extStart + best_read.length() <= extStart + read.length()) {
		min_end = best_extStart + best_read.length();
	} else {
		min_end = extStart + read.length();
	}

	for(unsigned int st = max_start; st < min_end; st++) {
		if(best_read.at(st-best_extStart) != read.at(st-extStart)) {
			mismatches++;
		}
	}

	if(mismatches <= extMismatches) {
		this->contigExtension->insertRead(extStart, read);
		this->Reads.push_back(readPosition);
		return true;
	}
	return false;
}
*/

bool Contig::SelectReadsForConsensus (unsigned int Extposition, string &sequence, const string & cons, unsigned int cons_start,
									  vector< pair<unsigned int, bool> > & low_rep, unsigned int mismatches){
		bool read_ok = true; // indicates whether the read contains a caracter != consensus in a low represented position
		vector <pair <unsigned int, bool> >::iterator l = low_rep.begin();
		unsigned int i = (Extposition < cons_start) ? cons_start-Extposition : 0;
		unsigned short errors = 0;

		while (l != low_rep.end() and (*l).first < Extposition + i){
			l++;
		}
		while (read_ok and i < sequence.size() and Extposition + i < cons_start + cons.size()){
			errors += (sequence.at(i) != cons.at(Extposition+i-cons_start));
			read_ok = (errors <= mismatches); // discard the current read if too many mismatches occur
			if (read_ok and l != low_rep.end() and Extposition+i == (*l).first){
				read_ok = (sequence.at((*l).first-Extposition) == cons.at((*l).first-cons_start));
				if (read_ok and not (*l).second){ // the read is ok but covers a not-represented char
					string s = sequence.substr(0,(*l).first-Extposition);
					sequence = s;
				}
				l++;
			}
			i++;
		}

		return read_ok;
}

short Contig::SelectReadsForConsensusBranch (const string & first_read_string, unsigned int first_read_start, const string & it_read_string,
				unsigned int it_read_start, unsigned short max_start, unsigned short min_end, 
				vector< pair<unsigned int, bool> > & low_rep, unsigned int mismatches, int branch_mismatch){
		
		//bool read_ok = true; // indicates whether the read contains a caracter != consensus in a low represented position
		short read_ok = 0;
		//  0: discard the read
		//  1: read is overlapping
		// -1: read is enough different to start a new branch
		vector <pair <unsigned int, bool> >::iterator l = low_rep.begin();
		unsigned short errors = 0;

		while (l != low_rep.end() and (*l).first < max_start){
			l++;
		}
		/*
		while (read_ok and l != low_rep.end() and l->first <= min_end){
			errors += (first_read_string.at(l->first-first_read_start) != it_read_string.at(l->first-it_read_start));
			read_ok = (errors <= mismatches); // discard the current read if too many mismatches occur
			l++;
		}
		*/

		while (l != low_rep.end() and l->first <= min_end){
			errors += (first_read_string.at(l->first-first_read_start) != it_read_string.at(l->first-it_read_start));
			l++;
		}

		if (errors <= mismatches){
			read_ok = 1;
		} else if (errors >= (unsigned int) branch_mismatch){
			read_ok = -1;
		}

		return read_ok;
}

bool Contig::MaybeMateFound(const string & read, unsigned int start, unsigned int globalMismatches) {

	unsigned int mismatches=0;

	for(unsigned int el = 0; el < read.length() ; el++) {
		if(contig.at(start+el) != read.at(el)) {
			mismatches++;
		}
	}
	if(mismatches <= globalMismatches) {
		this->contig = contig.substr(0,start+read.length());
		this->ContigStatus = MatePairFound;
		return true;
	}
	return false;
}


void Contig::extension(unsigned int thr, unsigned int max_contig_length, double perc_identity, bool no_more_ext, 
						unsigned int first_pos, bool branch) {
	if (no_more_ext){
		this->ContigStatus = NoMoreExtensions;
		return;
	}
	if(this->ContigStatus != ReadCycleFound) { // if I realize that a cycle as been found don't perform extension at all
		//if(this->firstExtendedPosition > 0) { // otherwise, if there is something to extend

		unsigned int cons_start, errors = 0;
		vector< pair<unsigned int, bool> > low_rep;
		string extension;
		if (not branch) {
			unsigned int numfing;
			if (overlap+numFingerprints > contig.size()){
				numfing = contig.size();
			} else {
				numfing = overlap+numFingerprints;
			}
			extension = this->contigExtension->returnConsensus(thr, numfing, errors, perc_identity, low_rep, cons_start);
		} else {
			extension = this->contigExtension->returnConsensusBranch (errors, low_rep, cons_start);
		}
		this->firstExtendedPosition = first_pos + cons_start;
		// compute extension and number of errors of such extension
		if(this->firstExtendedPosition + extension.length() > this->contig.length()) {
			contig = contig.substr(0, this->firstExtendedPosition);
			contig.append(extension);
			if(contig.length() < max_contig_length) { // length cutoff to avoid loops
				this->ContigStatus = Continue; // continue computation
			} else {
				this->ContigStatus = LentghExceed;
			}
		} else { // if number of errors is higher than threshold stop contig extension
			this->ContigStatus = RepetitiveSequence;
		}
		//} else { // no reads found, contig cannot be extended
		//	this->ContigStatus = NoMoreExtensions;
		//}
	}
}


void Contig::printContig(ofstream& ostrFile) {

	if(this->ContigStatus == MatePairFound) {
		ostrFile << ">contig" << this->contigNum <<"_pairFound" << endl;
	} else if (this->ContigStatus ==  LentghExceed ) {
		ostrFile  << ">contig" << this->contigNum <<"_LengthExceed" << endl;
	} else if (this->ContigStatus ==  RepetitiveSequence ) {
		ostrFile << ">contig" << this->contigNum <<"_repSeq" << endl;
	}  else if (this->ContigStatus ==  NoMoreExtensions ) {
		ostrFile << ">contig" << this->contigNum <<"_noMoreExt" << endl;
	}  else if (this->ContigStatus ==  ReadCycleFound ) {
		ostrFile << ">contig" << this->contigNum <<"_ReadCycle" << endl;
	} else {
		cout << "ERROR in contig " << this->contigNum << endl;
		ostrFile << ">contig" << this->contigNum <<"_erroneusStatus" << endl;
	}

	//ostrFile << this->contig << endl;
	ostrFile << this->returntContig() << endl;

}


void Contig::printContig(ofstream& ostrFile, unsigned int s_iter) {

	if(this->ContigStatus == MatePairFound) {
		ostrFile << ">contig" << this->contigNum << "_" << s_iter+1 << "_pairFound" << endl;
	} else if (this->ContigStatus ==  LentghExceed ) {
		ostrFile  << ">contig" << this->contigNum << "_" << s_iter+1 << "_LengthExceed" << endl;
	} else if (this->ContigStatus ==  RepetitiveSequence ) {
		ostrFile << ">contig" << this->contigNum << "_" << s_iter+1 << "_repSeq" << endl;
	}  else if (this->ContigStatus ==  NoMoreExtensions ) {
		ostrFile << ">contig" << this->contigNum << "_" << s_iter+1 << "_noMoreExt" << endl;
	}  else if (this->ContigStatus ==  ReadCycleFound ) {
		ostrFile << ">contig" << this->contigNum << "_" << s_iter+1 << "_ReadCycle" << endl;
	} else {
		cout << "ERROR in contig " << this->contigNum << endl;
		ostrFile << ">contig" << this->contigNum << "_" << s_iter+1 << "_erroneusStatus" << endl;
	}

	//ostrFile << this->contig << endl;
	ostrFile << this->returntContig() << endl;

}


void Contig::printContigMate(ofstream& ostrFile, bool mateFound) {

	if(this->ContigStatus == MatePairFound) {
		ostrFile << ">contig" << this->contigNum <<"_pairFound" << endl;
	} else if (this->ContigStatus ==  LentghExceed ) {
		ostrFile  << ">contig" << this->contigNum <<"_LengthExceed";
	} else if (this->ContigStatus ==  RepetitiveSequence ) {
		ostrFile << ">contig" << this->contigNum <<"_repSeq";
	}  else if (this->ContigStatus ==  NoMoreExtensions ) {
		ostrFile << ">contig" << this->contigNum <<"_noMoreExt";
	}  else if (this->ContigStatus ==  ReadCycleFound ) {
		ostrFile << ">contig" << this->contigNum <<"_ReadCycle";
	} else {
		cout << "ERROR in contig " << this->contigNum << endl;
		ostrFile << ">contig" << this->contigNum <<"_erroneusStatus" << endl;
	}

	if (mateFound){
		ostrFile << "_mateFound" << endl;
	} else {
		ostrFile << "_mateNotFound" << endl;
	}

	ostrFile << this->contig << endl;
}

}
