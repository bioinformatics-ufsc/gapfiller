/*
 * SetZ.cpp
 *
 *  Created on: 29/lug/2010
 *      Author: cdf
 */

#include "SetZ.h"

void SetZ::initZ(int errors, int block, unsigned long int q) {
	this->errors = errors;
	this->block = block;
	this->q = q;
	i[0] = block;
	Z z0;
	z0.error=0;
	z0.z=0;
	belongsZ0.insert(z0);

	backtrackZ(1, this->errors);

	int sizeZ = 0;
	int err=0;
	errorsInsetZ = new int[errors+1];
	set<unsigned long int> belongsZ0temp;
	set<unsigned long int>::const_iterator iterZ0temp;

	for(iterZ0 = belongsZ0.begin(); iterZ0 != belongsZ0.end(); ++iterZ0 ) {

		if(belongsZ0temp.insert(iterZ0->z).second) {
			if(iterZ0->error > err) {
				errorsInsetZ[err]=sizeZ;
				err++;
			}
			sizeZ++;
		}
	}
	errorsInsetZ[err]=sizeZ;

	this->size = sizeZ;
	this->Zarray = new unsigned long int[this->size];
	sizeZ = 0;

	belongsZ0temp.clear();
	for(iterZ0 = belongsZ0.begin(); iterZ0 != belongsZ0.end(); ++iterZ0 ) {
		if(belongsZ0temp.insert(iterZ0->z).second) {
			Zarray[sizeZ] = iterZ0->z;
			sizeZ++;
		}
	}

}

SetZ::~SetZ() {
	delete [] this->Zarray;
	delete [] this->errorsInsetZ;

}

void SetZ::backtrackZ(int j, int D) {

	if (j > D) return;

	unsigned long int z = 0;
	for (int jj = 1; jj <= j - 1; jj++) {
		if (u[jj] == 0) {
			z = (t[jj] * (1 << (2 * i[jj])) + z) % q;
		} else {
			z = (q - t[jj] * (1 << (2 * i[jj])) + z) % q;
		}
	}
	// we now generate a new value for the j-th position
	for (int ii = i[j - 1] - 1; ii >= 0; ii--)
		for (int tt = 1; tt <= 4 - 1; tt++) {
			Z z1;
			z1.error=j;
			z1.z=(tt * (1 << (2 * ii)) + z) % q;
			belongsZ0.insert(z1);
			Z z2;
			z2.error=j;
			z2.z=(q - tt * (1 << (2 * ii)) + z) % q;
			belongsZ0.insert(z2);
			i[j] = ii; t[j] = tt;
			u[j] = 0; this->backtrackZ(j + 1, D);
			u[j] = 1; this->backtrackZ(j + 1, D);
		}
}

