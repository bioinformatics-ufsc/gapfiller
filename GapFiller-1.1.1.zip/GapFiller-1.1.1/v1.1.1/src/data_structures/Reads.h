#ifndef READS_H_
#define READS_H_

#include <string>
#include <sstream>
#include <iostream>
#include <vector>
#include <set>
#include <algorithm>
#include <fstream>
#include <stdint.h>
using namespace std;



#include "common.h"

#define returnBit(var,pos) ((var) & (1<<(pos)));
#define setBit(var, pos) (var |= (1 << pos));
#define clearBit(var, pos) (var &= ~(1 << pos));


namespace reads
{



class Reads {
public:
	virtual ~Reads();
	Reads() {};
	Reads(const string & s, bool cs = false);
	Reads(const Reads &r); // copy constructor
	Reads & operator=(const Reads & r);


	unsigned int * get_read() { return read; } //* Return the read on +
	unsigned int * get_readRV() { return readRC; } //* Return the read on -

	unsigned short length(); // Return the length of the sequence.
	bool firstMate(); // true is the read is the first mate
	bool used(); // has the read already been used
	void setUsed(); // set the read to used
	bool seed(); // is the read a seed
	void setSeed(); // set the read to used

	void setCoverage(unsigned int coverage); // set 16-mer coverage
	unsigned int coverage(); // return 16-mer coverage

	string  toString(bool); // returns char representation of string

	unsigned int information; // stores, read's length, paired position, used status, seed status, read coverage
protected:
	unsigned int short cov;
	unsigned int *read; // read as given in input
	unsigned int *readRC; // read as given in input



};


class Seeds {
public:	
	Seeds ();
	Seeds(const string & seed, const string & mate);
	Seeds(const string & seed, const string & mate,
			const vector < pair <unsigned int, unsigned int> > & reads);
	~Seeds();

	string seed_string() {return this->_seed_string; }
	string seed_mate_string() {return this->_seed_mate_string; }
	size_t seed_length() {return this->_seed_length; }
	size_t seed_mate_length() {return this->_seed_mate_length; }
	vector < pair <unsigned int, unsigned int> > &extension_reads() {return this->_extension_reads; }
	unsigned int leftmost() {return this->_leftmost; }

	void add_read (unsigned int index, unsigned int position);
	void set_seed (const string & seed, const string & mate, const vector < pair <unsigned int, unsigned int> > & reads);
	void set_leftmost (unsigned int leftmost) {this->_leftmost = leftmost; } 

private:
	string _seed_string;
	string _seed_mate_string;
	size_t _seed_length;
	size_t _seed_mate_length;
	vector < pair <unsigned int, unsigned int> > _extension_reads; // read index (HASHvalues), read position in the contig
	unsigned int _leftmost;
};


class Extension {
public:
	Extension();
	Extension(unsigned  int size);
	~Extension();

	void insertRead(unsigned int startingPoint, const string & read);

	string returnConsensus();
	string returnConsensus(unsigned int  thr,unsigned int numFingerprints, unsigned int &errors, double perc_identity, 
				vector< pair<unsigned int, bool> > &low_rep, unsigned int& cons_start);
	string returnConsensusBranch (unsigned int &errors, vector< pair<unsigned int, bool> > &low_represented, unsigned int &cons_start);

	unsigned int returnFirstPosition();
	unsigned  int returnFarthest() {return farthest;}

	//void maybeInsertRead(unsigned int start , string read, unsigned int mismatches);

	unsigned  int farthest;

protected:
	unsigned int *A;
	unsigned int *C;
	unsigned int *G;
	unsigned int *T;
	unsigned int *Total;

	// unsigned  int farthest;
	unsigned  int size;

	int checkRepeatStatus(int a, int c, int g, int t, double perc_identity, bool& represented);
	string returnMAX(int,int,int,int);
	string returnMAX(int a, int c, int g, int t, bool &represented);

};

class Contig {



public:


	enum ExtensionStatus {Continue, ReadCycleFound, NoMoreExtensions, RepetitiveSequence, MatePairFound, LentghExceed};


	Contig();
	Contig(const string &contig, unsigned int contigNum, unsigned int extensionLength, unsigned long int q, unsigned long int h, unsigned int BL, unsigned int overlap, unsigned int numFingerprints);
	Contig(const string &contig, const set<unsigned int> &reads_used, unsigned int contigNum, unsigned int extensionLength, unsigned long int q, unsigned long int h, unsigned int BL, unsigned int overlap, unsigned int numFingerprints);

	~Contig();

	string returntContig() {return contig;}
	void printContig();
	void printContig(ofstream& ostrFile);
	void printContig(ofstream& ostrFile, unsigned int s_iter);
	void printContigMate(ofstream& ostrFile, bool mateFound);

	void InitializeExtension();
	void DeleteExtension();
	unsigned long int ComputeFingerprint(int n);
	unsigned long int ComputeFingerprintForCheck(unsigned int s);

	bool MaybeInsertRead(const string & read, unsigned int finNum,  unsigned int extStart, unsigned int localMismatches,
						unsigned int readPosition, bool no_cycle);
	void InsertRead(const string & read, unsigned int start, unsigned int extStart, unsigned int readPosition);
	unsigned short Mismatches(const string & read, unsigned int start, unsigned int extStart);

	/*
	bool MaybeReadExt(unsigned int start, string best_read, unsigned int best_extStart, string read, unsigned int extStart, unsigned int extMismatches, unsigned int readPosition);
	*/

	bool SelectReadsForConsensus (unsigned int extPosition, string & sequence, const string & cons, unsigned int cons_start,
									vector< pair<unsigned int, bool> > & low_rep, unsigned int mismatches);
	/*
	bool SelectReadsForConsensusBranch (string first_read_string, unsigned int first_read_start, string it_read_string, 
									unsigned int it_read_start, unsigned short max_start, unsigned short min_end, 
									vector< pair<unsigned int, bool> > low_rep, unsigned int mismatches);
	*/
	short SelectReadsForConsensusBranch (const string & first_read_string, unsigned int first_read_start, const string & it_read_string,
					unsigned int it_read_start, unsigned short max_start, unsigned short min_end,
					vector< pair<unsigned int, bool> > & low_rep, unsigned int mismatches, int branch_mismatches);

	bool MaybeMateFound(const string & read, unsigned int start, unsigned int globalMismatches);

	ExtensionStatus returnStatus() { return ContigStatus;}
	void setStatus(ExtensionStatus status) { this->ContigStatus = status;}

	bool extension();
	void extension(unsigned int thr, unsigned int max_contig_length, double perc_identity, bool no_more_ext, unsigned int first_pos, bool branch);

	unsigned int ReturnAreaWithNoFing() {return this->AreaWithNoFing;}
	unsigned int ReturnContigLength() {return this->contig.length();}
	unsigned int ReturnOverlap() {return this->overlap;}

	//string returnConsensus(unsigned int thr,unsigned int numFingerprints, unsigned int first_pos);
	//string returnConsensus(unsigned int thr,unsigned int numFingerprints, unsigned int first_pos, double perc_identity);

	Extension *contigExtension;
	unsigned int extension_length() {return this->extensionLength;} 
	unsigned long int return_q() {return this->q; }
	unsigned long int return_h() {return this->h; }
	unsigned int num_fingerprints() {return this->numFingerprints; }

	set <unsigned int> reads_used () { return this->InsertedReads; }
	void resize (unsigned int new_length) { if (contig.size() > new_length) contig.resize(new_length); }

private:

	ExtensionStatus ContigStatus;

	unsigned int extensionLength;
	unsigned int contigNum;
	unsigned int firstExtendedPosition;
	string contig;

	unsigned long int q;
	unsigned long int h;
	unsigned int BL;
	unsigned int overlap;
	unsigned int numFingerprints;
	//unsigned int clustRepThr;
	unsigned int AreaWithNoFing;

	vector<unsigned int> Reads;

	set<unsigned int> InsertedReads;

	inline unsigned long int fill_right(unsigned long int Nq, char base);
	inline unsigned long int roll_right(char first_digit, unsigned long int Nq, char base);

};


}
#endif /*READS_H_*/
