/*
 * GlobalToLocal.h
 *
 *  Created on: 29/lug/2010
 *      Author: cdf
 */

#ifndef GLOBALTOLOCAL_H_
#define GLOBALTOLOCAL_H_

#include <string>
#include <iostream>
#include <cstdlib>
using namespace std;

class GlobalToLocal {
public:
	~GlobalToLocal() {
		if (Contigs > 0) {
			delete [] startPositions;
			delete [] endPositions;
			delete [] contigsNames;
		}
	}
	GlobalToLocal(const GlobalToLocal &GTL); // copy constructor
	GlobalToLocal & operator=(const GlobalToLocal & GTL);
	GlobalToLocal();
	GlobalToLocal(int numContig);
	int searchContig(int GlobalCoordinate);


	int Contigs; //Number of contigs
	int *startPositions;
	int *endPositions;
	string *contigsNames;
};

#endif /* GLOBALTOLOCAL_H_ */
