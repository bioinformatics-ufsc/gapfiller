/*
 * Radix_Sort_By_Index.h
 *
 *  Created on: 01/dic/2010
 *      Author: cdf
 */

#ifndef RADIX_SORT_BY_INDEX_H_
#define RADIX_SORT_BY_INDEX_H_

#include <cmath>
using namespace std;

#include "Counting_Sort_By_Index.h"

namespace algorithms {

template <class T_Items, class T_Numbers>
class Radix_Sort_By_Index {
public:

	typedef pair<T_Items *, T_Numbers *> t_element;

	static t_element * sort(const t_element * original, size_t length, size_t min_index, size_t max_index, size_t max_value) {
		t_element * input_items;
		t_element * temp_items;
		t_element * output_items;
		min_index++;
		max_index++;
		if (min_index > max_index) {
			size_t temp = min_index;
			min_index = max_index;
			max_index = temp;
		}

		input_items = new t_element [length];
		output_items = new t_element [length];
		for (size_t i = 0; i < length; i++)
			input_items[i] = original[i];


		for (size_t d = max_index; d >= min_index; d--) {
			// Prepare input
			Counting_Sort_By_Index<T_Items,T_Numbers>::sort(input_items, length, d-1, max_value, output_items);
			temp_items = input_items;
			input_items = output_items;
			output_items = temp_items;
		}
		delete [] output_items;
		return input_items;
	}
};

}

#endif /* RADIX_SORT_BY_INDEX_H_ */

