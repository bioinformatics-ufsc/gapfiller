/*
 * Counting_Sort.h
 *
 *  Created on: 1-dic-2008
 *      Author: cdf
 */

#ifndef COUNTING_SORT_H_
#define COUNTING_SORT_H_

#include <utility>
#include <cstddef>
using namespace std;

namespace algorithms {

typedef unsigned short int t_digit;

#define digits_base 16

#if digits_base != 16
#include <cmath>
using namespace std;
#endif

template <class T_Items, class T_Numbers = unsigned long long int>
class Counting_Sort {
public:

	typedef T_Items * t_io_set;
	typedef t_digit * t_input_digits;

	Counting_Sort() {
		// Nothing to do
	}
	virtual ~Counting_Sort() {
		// Nothing to do
	}

	// input & output vectors must be allocated!
	static void sort(t_io_set input_items, t_input_digits input_digits, size_t length, t_io_set output_items) {
		size_t * counts = new size_t[digits_base];
		size_t k;

		for (k = 0; k < digits_base; k++)
			counts[k] = 0;

		for (k = 0; k < length; k++)
			counts[input_digits[k]]++;

		for (k = 1; k < digits_base; k++)
			counts[k] += counts[k-1];

		k = length;
		do {
			k--;
			output_items[counts[input_digits[k]] - 1] = input_items[k];
			counts[input_digits[k]]--;
		} while (k > 0);

		delete [] counts;
	}

	static t_digit compute_digit(T_Numbers number, size_t digit) {
	#if digits_base == 16
		// optimized for 4 bit
		return (number >> (4*digit)) & 0xF;
	#else
		// work with every base
		number = number / (pow(digits_base,digit));
		return number % digits_base;
	#endif
	}

};

}

#endif /* COUNTING_SORT_H_ */
