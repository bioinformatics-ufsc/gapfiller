/*
 * Counting_Sort_By_Index.h
 *
 *  Created on: 02/dic/2010
 *      Author: cdf
 */

#ifndef COUNTING_SORT_BY_INDEX_H_
#define COUNTING_SORT_BY_INDEX_H_

#include <utility>
#include <cstddef>
using namespace std;

namespace algorithms {

template <class T_Items, class T_Numbers>
class Counting_Sort_By_Index {
public:
	typedef pair<T_Items *, T_Numbers *> t_element;

	// input & output vectors must be allocated!
	static void sort(t_element * input_items, size_t length, size_t position, size_t max, t_element * output_items) {
		size_t * counts = new size_t[max+1];
		size_t k;

		for (k = 0; k < max; k++)
			counts[k] = 0;

		for (k = 0; k < length; k++)
			counts[input_items[k].second[position]]++;

		for (k = 1; k < max; k++)
			counts[k] += counts[k-1];

		k = length;
		do {
			k--;
			output_items[counts[input_items[k].second[position]] - 1] = input_items[k];
			counts[input_items[k].second[position]]--;
		} while (k > 0);

		delete [] counts;
	}

};

}

#endif /* COUNTING_SORT_BY_INDEX_H_ */
