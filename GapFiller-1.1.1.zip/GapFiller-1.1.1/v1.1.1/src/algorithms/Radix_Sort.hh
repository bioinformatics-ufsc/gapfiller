/*
 * Radix_Sort.h
 *
 *  Created on: 1-dic-2008
 *      Author: cdf
 */

#ifndef RADIX_SORT_H_
#define RADIX_SORT_H_

#include <cmath>
using namespace std;

#include "Counting_Sort.hh"

namespace algorithms {

template <class T_Items, class T_Numbers = unsigned long long int>
class Radix_Sort {
public:

	typedef pair<T_Items, T_Numbers> t_element;
	typedef t_element *t_io_set;

	Radix_Sort() {
		// Nothing to do
	}
	virtual ~Radix_Sort() {
		// Nothing to do
	}

	// input vectors must be allocated!
	static void sort(t_io_set & input_items , size_t max, size_t length) {
		t_io_set temp_items, output_items;
		t_digit * input_digits;

		output_items = new t_element [length];
		input_digits = new t_digit [length];

		size_t digits = ceil(log(max)/log(digits_base));

		for (unsigned int d = 0; d <= digits; d++) {
			// Prepare input
			for (size_t i = 0; i < length; i++)
				input_digits[i] = Counting_Sort<t_element,T_Numbers>::compute_digit(input_items[i].second, d);
			Counting_Sort<t_element,T_Numbers>::sort(input_items, input_digits, length, output_items);
			temp_items = input_items;
			input_items = output_items;
			output_items = temp_items;
		}
		delete [] input_digits;
		delete [] output_items;
	}
};

}

#endif /* RADIX_SORT_H_ */
